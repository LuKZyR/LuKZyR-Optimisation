﻿param([switch]$NonInteractif, [string]$Description = "Avant LuKZyR Optimisation")
# Crée UN point de restauration (appelé une seule fois par l'interface avant d'appliquer).
# Codes de sortie : 0 = point VRAIMENT créé maintenant (nouveau numéro de séquence) ; 2 = pas de nouveau point, mais
# un point « $Description » de moins de 10 min existe et est réutilisé ; 1 = création/réutilisation impossible
# (l'interface peut demander s'il faut continuer) ; 3 = sauvegarde préalable impossible ;
# 4 = fréquence d'origine impossible à rétablir. Les codes 3 et 4 imposent l'arrêt.
# La fréquence minimale entre deux points (SystemRestorePointCreationFrequency) est d'abord retenue
# pour « Tout annuler », mise à 0 le temps de créer le point, puis remise AUSSITÔT à sa valeur d'origine
# (supprimée si elle était absente) : Windows garde son délai normal de 24 h entre deux points automatiques.
$ErrorActionPreference = "SilentlyContinue"
if ($NonInteractif) { [Console]::OutputEncoding = New-Object Text.UTF8Encoding $false }
Write-Host "==> Point de restauration"
$cle = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
$nom = "SystemRestorePointCreationFrequency"
# 1. valeur d'origine retenue pour « Tout annuler » AVANT toute écriture (dans tous les cas, même installation d'applis seule)
$sauv = Join-Path $PSScriptRoot "Sauvegarde-Reglages.ps1"
if (-not (Test-Path -LiteralPath $sauv -PathType Leaf)) {
  Write-Host "ÉCHEC : la sauvegarde préalable est obligatoire, mais le script est introuvable : $sauv" -ForegroundColor Red
  exit 3
}
$ancienEap = $ErrorActionPreference
$erreurSauv = ""; $codeSauv = 0
try {
  # Ne pas rediriger la sortie : si le JSON est illisible, le diagnostic exact doit rester visible.
  $ErrorActionPreference = "Stop"
  $global:LASTEXITCODE = 0
  & $sauv -Sauvegarder -NonInteractif -Elements "restauration"
  $appelSauvOk = $?
  $codeSauv = $global:LASTEXITCODE
  if (-not $appelSauvOk) { $erreurSauv = "le script de sauvegarde n'a pas pu être exécuté" }
} catch {
  $erreurSauv = "le script de sauvegarde n'a pas pu démarrer ($($_.Exception.Message))"
} finally {
  $ErrorActionPreference = $ancienEap
}
if ($erreurSauv) {
  Write-Host "ÉCHEC : $erreurSauv. Aucun réglage de restauration n'a été modifié." -ForegroundColor Red
  exit 3
}
if ($codeSauv -ne 0) {
  Write-Host "ÉCHEC : la sauvegarde préalable a échoué (code $codeSauv). Aucun réglage de restauration n'a été modifié." -ForegroundColor Red
  exit 3
}
$ok = $false; $err = ""; $reutilise = $null
$frequenceModifiee = $false; $erreurFrequence = ""
try {
  Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction Stop
  $seqAvant = 0
  foreach ($p in @(Get-ComputerRestorePoint -ErrorAction Stop)) {
    $seqAvant = [math]::Max([int64]$seqAvant, [int64]$p.SequenceNumber)
  }
  if (-not (Test-Path -LiteralPath $cle -ErrorAction Stop)) { New-Item -Path $cle -ErrorAction Stop | Out-Null }
  $k = Get-Item -LiteralPath $cle -ErrorAction Stop
  $avait = @($k.GetValueNames()) -contains $nom
  if ($avait) {
    $orig = $k.GetValue($nom, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $typeOrig = $k.GetValueKind($nom)
  }
  Set-ItemProperty -Path $cle -Name $nom -Value 0 -Type DWord -ErrorAction Stop
  $frequenceModifiee = $true
  Checkpoint-Computer -Description $Description -RestorePointType MODIFY_SETTINGS -ErrorAction Stop -WarningVariable avert -WarningAction SilentlyContinue
  foreach ($p in @(Get-ComputerRestorePoint -ErrorAction Stop)) {
    if ([int64]$p.SequenceNumber -gt $seqAvant -and $p.Description -eq $Description) { $ok = $true; break }
  }
  if (-not $ok) { $err = if ($avert) { "$avert" } else { "aucun nouveau point correspondant trouvé" } }
} catch { $err = $_.Exception.Message }
finally {
  if ($frequenceModifiee) {
    try {
      if ($avait) { Set-ItemProperty -Path $cle -Name $nom -Value $orig -Type $typeOrig -ErrorAction Stop }
      else { Remove-ItemProperty -Path $cle -Name $nom -ErrorAction Stop }
    } catch { $erreurFrequence = $_.Exception.Message }
  }
}
if ($erreurFrequence) {
  Write-Host "ÉCHEC : impossible de rétablir la fréquence des points de restauration ($erreurFrequence). Les optimisations sont interrompues. La valeur d'origine est enregistrée dans la sauvegarde de « Tout annuler »." -ForegroundColor Red
  if (-not $NonInteractif) { Read-Host "Appuie sur Entrée pour fermer" }
  exit 4
}
if (-not $ok) {
  try {
    $limite = (Get-Date).AddMinutes(-10)
    foreach ($p in @(Get-ComputerRestorePoint -ErrorAction Stop | Where-Object Description -eq $Description | Sort-Object SequenceNumber -Descending)) {
      $date = $p.ConvertToDateTime($p.CreationTime)
      if ($date -gt $limite) { $reutilise = $date; break }
    }
  } catch { Write-Host "Impossible de vérifier les points récents ($($_.Exception.Message))." -ForegroundColor Yellow }
}
if ($ok) { Write-Host "Point de restauration « $Description » créé." -ForegroundColor Green }
elseif ($reutilise) {
  Write-Host "Aucun nouveau point créé ($err)." -ForegroundColor Yellow
  Write-Host "Le point « $Description » créé à $($reutilise.ToString('HH:mm')) (il y a $([math]::Max(0, [int]((Get-Date) - $reutilise).TotalMinutes)) min) est RÉUTILISÉ : il protège aussi ces changements." -ForegroundColor Yellow
}
else {
  Write-Host "ÉCHEC : le point de restauration n'a pas pu être créé ($err)." -ForegroundColor Red
  Write-Host "Vérifie que la Protection du système est activée sur $env:SystemDrive et qu'il reste de la place sur le disque." -ForegroundColor Yellow
}
if (-not $NonInteractif) { Read-Host "Appuie sur Entrée pour fermer" }
if ($ok) { exit 0 } elseif ($reutilise) { exit 2 } else { exit 1 }
