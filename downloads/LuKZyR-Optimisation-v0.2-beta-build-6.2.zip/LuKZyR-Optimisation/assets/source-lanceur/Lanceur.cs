﻿// LuKZyR Optimisation - lanceur .exe
// Demande les droits administrateur (manifeste requireAdministrator) puis lance l'interface PowerShell
// scripts\LuKZyR-Optimisation.ps1 située à côté de l'exe. Aucune dépendance (.NET Framework 4.x de Windows).
// v5.2 : affiche TOUT DE SUITE un écran de chargement (même look que celui de l'appli) pendant que
// PowerShell démarre ; il passe la main dès que l'écran de chargement de l'appli (ou la fenêtre) apparaît.
using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using EventWaitHandle = System.Threading.EventWaitHandle;
using EventResetMode = System.Threading.EventResetMode;
using Microsoft.Win32;

[assembly: AssemblyTitle("LuKZyR Optimisation")]
[assembly: AssemblyProduct("LuKZyR Optimisation")]
[assembly: AssemblyDescription("Lanceur de LuKZyR Optimisation")]
[assembly: AssemblyCompany("Lukzyr")]
[assembly: AssemblyCopyright("Copyright © 2026 Lukzyr")]
[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.2")]
[assembly: AssemblyInformationalVersion("0.2.0-beta+6.2")]

sealed class Chargement : LkSurfaceChargement {
  readonly Timer minuteur = new Timer();
  readonly EventWaitHandle relai;
  readonly Func<Point?, long, Process> lancer;
  readonly long debut = Stopwatch.GetTimestamp();
  Process proc;

  internal Chargement(bool clair, bool en, string racine, string version, EventWaitHandle relai, Func<Point?, long, Process> lancer)
      : base(clair, version, racine, en) {
    this.relai = relai; this.lancer = lancer;
    Text = "LuKZyR Optimisation - lanceur";
    AfficherProgression(0f, en ? "Starting PowerShell…" : "Démarrage de PowerShell…");
    AfficherTemps(0, false);
    minuteur.Interval = 60; minuteur.Tick += Tick;
  }
  protected override void OnShown(EventArgs e) {
    base.OnShown(e); Refresh();
    try { proc = lancer(Location, debut); minuteur.Start(); }
    catch (Exception ex) { Hide(); MessageBox.Show("Impossible de lancer PowerShell :\n" + ex.Message, "LuKZyR Optimisation", MessageBoxButtons.OK, MessageBoxIcon.Error); Close(); }
  }
  void Tick(object o, EventArgs e) {
    double ecoule = (Stopwatch.GetTimestamp() - (double)debut) / Stopwatch.Frequency;
    if (relai.WaitOne(0) || ecoule > 120) { Close(); return; }
    AfficherTemps(ecoule, ecoule >= 12);
    if (proc == null || !proc.HasExited) return;
    int code = proc.ExitCode;
    if (code != 0 && code != 3) { minuteur.Stop(); Hide(); Lanceur.SignalerPlantage(code); }
    Close();
  }
  protected override void Dispose(bool disposing) {
    if (disposing) { minuteur.Dispose(); if (proc != null) proc.Dispose(); }
    base.Dispose(disposing);
  }
}


static class Lanceur {
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int MessageBoxW(IntPtr h, string texte, string titre, uint type);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

  static string dossierDonnees = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Lukzyr");
  static readonly string FichierErreurs = Path.Combine(dossierDonnees, "erreurs-powershell-" + Process.GetCurrentProcess().Id + ".txt");
  // v5.6 : message visible + journal quand l'appli s'arrête au démarrage
  public static void SignalerPlantage(int code) {
    string detail = "";
    try { if (File.Exists(FichierErreurs)) { detail = File.ReadAllText(FichierErreurs).Trim(); if (detail.Length > 1200) detail = "..." + detail.Substring(detail.Length - 1200); } } catch { }
    string journal = Path.Combine(dossierDonnees, "plantage-demarrage.txt");
    try { File.AppendAllText(journal, "[" + DateTime.Now.ToString("s") + "] code " + code + "\r\n" + detail + "\r\n"); } catch { }
    MessageBoxW(IntPtr.Zero, "LuKZyR Optimisation n'a pas pu démarrer (code " + code + ").\n\n" + (detail.Length > 0 ? detail + "\n\n" : "") + "Détails enregistrés dans :\n" + journal, "LuKZyR Optimisation", 0x10);
  }

  [STAThread]
  static int Main() {
    LkIdentiteAppli.EnregistrerProcessus();
    string dossier = AppDomain.CurrentDomain.BaseDirectory;
    string script = Path.Combine(dossier, "scripts", "LuKZyR-Optimisation.ps1");
    if (!File.Exists(script)) {
      MessageBoxW(IntPtr.Zero, "Fichier introuvable :\n" + script + "\n\nGarde l'exe dans le dossier LuKZyR-Optimisation (avec le dossier scripts).", "LuKZyR Optimisation", 0x10);
      return 1;
    }
    string ps = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe");
    if (!File.Exists(ps)) ps = "powershell.exe";
    string idChargement = Guid.NewGuid().ToString("N");
    bool lance = false;
    Func<Point?, long, Process> lancer = (position, debut) => {
      if (lance) return null; lance = true;
      // v5.6 : la sortie d'erreur de PowerShell va dans un fichier (cmd /c ... 2> fichier) : lisible si l'appli
      // s'arrête au démarrage, sans tuyau qui se fermerait quand le lanceur disparaît
      try { Directory.CreateDirectory(dossierDonnees); File.Delete(FichierErreurs); } catch { }
      string cmd = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "cmd.exe");
      var si = new ProcessStartInfo(cmd, "/d /s /v:off /c \"\"%LK_START_POWERSHELL%\" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%LK_START_SCRIPT%\" 2>\"%LK_START_ERRORS%\"\"");
      si.UseShellExecute = false; si.CreateNoWindow = true; si.WorkingDirectory = dossier;
      si.EnvironmentVariables["LK_START_POWERSHELL"] = ps;
      si.EnvironmentVariables["LK_START_SCRIPT"] = script;
      si.EnvironmentVariables["LK_START_ERRORS"] = FichierErreurs;
      si.EnvironmentVariables["LK_SPLASH_READY"] = idChargement;
      si.EnvironmentVariables["LK_SPLASH_DEBUT"] = debut.ToString(CultureInfo.InvariantCulture);
      if (position.HasValue) {
        Point p = position.Value;
        si.EnvironmentVariables["LK_SPLASH_POSITION"] = p.X.ToString(CultureInfo.InvariantCulture) + "," + p.Y.ToString(CultureInfo.InvariantCulture);
      } else { si.EnvironmentVariables.Remove("LK_SPLASH_POSITION"); }
      return Process.Start(si);
    };
    // Préférences de l'appli (thème, langue) pour un écran de chargement identique
    bool clair = false, en = false;
    try {
      using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Lukzyr")) {
        if (k != null) { clair = string.Equals(k.GetValue("Theme") as string, "clair"); string l = k.GetValue("Langue") as string; en = l == "en" || (l != "fr" && System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName != "fr"); }
        else en = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName != "fr";
      }
    } catch { }
    string version = "v0.2" + (en ? " beta" : " bêta");
    try {
      SetProcessDPIAware();
      Application.EnableVisualStyles();
      using (var relai = new EventWaitHandle(false, EventResetMode.ManualReset, @"Local\LuKZyR-Chargement-" + idChargement))
      using (var ecran = new Chargement(clair, en, dossier, version, relai, lancer)) Application.Run(ecran);
      return 0;
    } catch (Exception) {
      // Écran de chargement impossible : on lance quand même l'appli
      try { lancer(null, Stopwatch.GetTimestamp()); return 0; } catch (Exception ex2) { MessageBoxW(IntPtr.Zero, "Impossible de lancer PowerShell :\n" + ex2.Message, "LuKZyR Optimisation", 0x10); return 2; }
    }
  }
}
