using System;
using System.IO;
using System.Runtime.InteropServices;

public static class LkIdentiteAppli {
  public const string AppId = "LuKZyR.Optimisation";
  const string Nom = "LuKZyR Optimisation";
  static readonly Guid Groupe = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");

  [StructLayout(LayoutKind.Sequential)]
  struct PropertyKey {
    internal Guid Groupe;
    internal uint Id;
  }

  // Le PROPVARIANT natif mesure 16 octets en x86 et 24 en x64.
  [StructLayout(LayoutKind.Sequential)]
  struct PropVariant {
    internal ushort Type, Reserve1, Reserve2, Reserve3;
    internal IntPtr Valeur, Reserve;

    internal PropVariant(string texte) {
      Type = 31; // VT_LPWSTR
      Reserve1 = Reserve2 = Reserve3 = 0;
      Valeur = Marshal.StringToCoTaskMemUni(texte);
      Reserve = IntPtr.Zero;
    }
  }

  [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IPropertyStore {
    [PreserveSig] int GetCount(out uint count);
    [PreserveSig] int GetAt(uint index, out PropertyKey key);
    [PreserveSig] int GetValue(ref PropertyKey key, out PropVariant value);
    [PreserveSig] int SetValue(ref PropertyKey key, ref PropVariant value);
    [PreserveSig] int Commit();
  }

  [DllImport("shell32.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
  static extern int SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string appId);
  [DllImport("shell32.dll", ExactSpelling = true)]
  static extern int SHGetPropertyStoreForWindow(IntPtr hwnd, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IPropertyStore store);

  public static void EnregistrerProcessus() {
    try { SetCurrentProcessExplicitAppUserModelID(AppId); } catch { }
  }

  internal static string Lanceur(string racine) { return Path.Combine(racine, Nom + ".exe"); }

  internal static string RessourceIcone(string racine) {
    string ico = Path.Combine(racine, "assets", "lukzyr.ico");
    if (File.Exists(ico)) return ico + ",0";
    string lanceur = Lanceur(racine);
    return File.Exists(lanceur) ? lanceur + ",0" : null;
  }

  static void Ecrire(IPropertyStore store, uint id, string texte) {
    var key = new PropertyKey { Groupe = Groupe, Id = id };
    var valeur = new PropVariant(texte);
    try { store.SetValue(ref key, ref valeur); }
    finally { Marshal.FreeCoTaskMem(valeur.Valeur); }
  }

  public static void EnregistrerFenetre(IntPtr hwnd, string racine) {
    try {
      Guid iid = typeof(IPropertyStore).GUID;
      IPropertyStore store;
      if (SHGetPropertyStoreForWindow(hwnd, ref iid, out store) < 0 || store == null) return;
      try {
        string lanceur = Lanceur(racine);
        string icone = RessourceIcone(racine);
        if (File.Exists(lanceur)) {
          Ecrire(store, 2, "\"" + lanceur + "\""); // RelaunchCommand
          Ecrire(store, 4, Nom);                     // RelaunchDisplayNameResource
        }
        if (icone != null) Ecrire(store, 3, icone); // RelaunchIconResource
        // Définir l'identité après les métadonnées, avant que la fenêtre soit visible.
        Ecrire(store, 5, AppId);
      } finally { Marshal.ReleaseComObject(store); }
    } catch { }
  }
}
