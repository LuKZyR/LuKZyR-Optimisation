﻿// Ecran de chargement WinForms partage entre le lanceur et PowerShell.
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#if !LK_LANCEUR
[assembly: AssemblyTitle("LuKZyR Optimisation - chargement")]
[assembly: AssemblyProduct("LuKZyR Optimisation")]
[assembly: AssemblyCompany("Lukzyr")]
[assembly: AssemblyCopyright("Copyright © 2026 Lukzyr")]
[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.2")]
[assembly: AssemblyInformationalVersion("0.2.0-beta+6.2")]
#endif

internal sealed class ProgressionChargement {
  internal float Valeur { get; private set; }
  internal ProgressionChargement(float valeur) { Valeur = valeur; }
  internal void Avancer(float cible, double secondes, bool reduit) {
    cible = Math.Max(Valeur, Math.Min(cible, 100f));
    Valeur = reduit ? cible : Valeur + (cible - Valeur) * (float)(1 - Math.Exp(-15 * Math.Max(0, secondes)));
    if (cible - Valeur < 0.15f) Valeur = cible;
  }
  internal static double Opacite(double secondes) {
    double reste = Math.Max(0, Math.Min(1, 1 - secondes / 0.16));
    return reste * reste * (3 - 2 * reste);
  }
  internal static int Intervalle(float affiche, float cible, bool fermeture) {
    return fermeture || cible - affiche >= 0.15f ? 25 : 100;
  }
}

internal class LkSurfaceChargement : Form {
  [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);
  [DllImport("user32.dll")] static extern bool SystemParametersInfo(int action, int param, ref int valeur, int flags);
  readonly string racine, version;
  readonly bool anglais;
  readonly Color fond, bord, texte, gris, acc, piste, puce, attente;
  readonly Color debut, fin;
  readonly float s;
  readonly Font titre, etiquette, status, nombre;
  readonly Icon iconeFenetre;
  Bitmap decor;
  float pourcent;
  string etape = "";
  int secondes = -1;
  bool attenteLongue;
  protected bool ImageDessinee { get; private set; }

  internal static bool ReduireMouvement(bool preference) {
    int active = 1;
    try { if (SystemParametersInfo(0x1042, 0, ref active, 0) && active == 0) return true; } catch { }
    return preference;
  }
  internal LkSurfaceChargement(bool clair, string version, string racine, bool anglais) {
    this.racine = racine; this.version = version; this.anglais = anglais;
    fond = C(clair ? "#f5f7fc" : "#141723"); bord = C(clair ? "#d8deeb" : "#303851");
    texte = C(clair ? "#171c30" : "#f2f4ff"); gris = C(clair ? "#475371" : "#aab3ca");
    acc = C(clair ? "#5835b4" : "#c6b6ff"); piste = C(clair ? "#dce1ee" : "#303652");
    puce = C(clair ? "#ebe5ff" : "#282440"); debut = C(clair ? "#4d54c8" : "#69bcf6"); fin = C(clair ? "#704adc" : "#ae8cff");
    attente = C(clair ? "#8b4b06" : "#ffd286");
    using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) {
      Rectangle bureau = Screen.PrimaryScreen.WorkingArea;
      s = Math.Min(Math.Max(1f, g.DpiX / 96f), Math.Min(bureau.Width / 500f, bureau.Height / 238f));
    }
    FormBorderStyle = FormBorderStyle.None; StartPosition = FormStartPosition.CenterScreen;
    AutoScaleMode = AutoScaleMode.None; ClientSize = new Size(S(480), S(219)); BackColor = fond;
    DoubleBuffered = true; ShowInTaskbar = true;
    AccessibleName = anglais ? "LuKZyR startup" : "Démarrage de LuKZyR";
    titre = Police(25, FontStyle.Bold);
    etiquette = Police(12, FontStyle.Regular);
    status = Police(14, FontStyle.Regular);
    nombre = Police(14, FontStyle.Bold);
    try {
      string chemin = Path.Combine(racine, "assets", "lukzyr.ico");
      if (File.Exists(chemin)) { iconeFenetre = new Icon(chemin); Icon = iconeFenetre; }
    } catch { }
  }
  static Color C(string h) { return ColorTranslator.FromHtml(h); }
  int S(float n) { return (int)Math.Round(n * s); }
  Rectangle Zone(int x, int y, int w, int h) { return new Rectangle(S(x), S(y), S(w), S(h)); }
  Font Police(float taille, FontStyle style) { return new Font("Segoe UI", taille * s, style, GraphicsUnit.Pixel); }
  protected void ReprendrePosition(string position) {
    if (string.IsNullOrEmpty(position)) return;
    string[] parties = position.Split(',');
    int x, y;
    if (parties.Length != 2 || !int.TryParse(parties[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out x)
        || !int.TryParse(parties[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out y)) return;
    Point origine = new Point(x, y);
    Rectangle fenetre = new Rectangle(origine, Size);
    foreach (Screen ecran in Screen.AllScreens) {
      Rectangle zone = ecran.WorkingArea;
      if (!zone.Contains(origine) || !zone.Contains(fenetre)) continue;
      StartPosition = FormStartPosition.Manual;
      Location = origine;
      return;
    }
  }
  internal static double TempsLanceur(string valeur) {
    long debut;
    if (!long.TryParse(valeur, NumberStyles.None, CultureInfo.InvariantCulture, out debut)) return 0;
    double age = (Stopwatch.GetTimestamp() - (double)debut) / Stopwatch.Frequency;
    return age >= 0 && age <= 120 ? age : 0;
  }
  internal static string FormaterTemps(int secondes, bool anglais) {
    string duree = secondes < 60 ? secondes + " s" : string.Format("{0} min {1:00} s", secondes / 60, secondes % 60);
    return (anglais ? "Elapsed · " : "Temps écoulé · ") + duree;
  }
  static GraphicsPath Arrondi(RectangleF r, float rayon) {
    GraphicsPath p = new GraphicsPath();
    float d = Math.Min(rayon * 2, Math.Min(r.Width, r.Height));
    if (d < 1) { p.AddRectangle(r); return p; }
    p.AddArc(r.Left, r.Top, d, d, 180, 90);
    p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
    p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
    p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
    p.CloseFigure(); return p;
  }
  const TextFormatFlags Texte = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
  Bitmap CreerDecor() {
    Bitmap bm = new Bitmap(ClientSize.Width, ClientSize.Height);
    using (Graphics g = Graphics.FromImage(bm)) {
      g.Clear(fond); g.SmoothingMode = SmoothingMode.AntiAlias;
      using (Pen pen = new Pen(bord)) g.DrawRectangle(pen, 0, 0, bm.Width - 1, bm.Height - 1);
      Rectangle bande = Zone(1, 1, 478, 4);
      using (var b = new LinearGradientBrush(bande, debut, fin, 0f)) g.FillRectangle(b, bande);
      using (GraphicsPath p = Arrondi(Zone(26, 31, 64, 64), S(16)))
      using (var b = new SolidBrush(puce)) g.FillPath(b, p);
      try {
        using (Image logo = Image.FromFile(Path.Combine(racine, "assets", "logo.png"))) {
          g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.DrawImage(logo, Zone(38, 43, 40, 40));
        }
      } catch { TextRenderer.DrawText(g, "L", titre, Zone(26, 31, 64, 64), acc, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine); }
      TextRenderer.DrawText(g, "LuKZyR Optimisation", titre, Zone(106, 35, 350, 36), texte, Texte);
      TextRenderer.DrawText(g, version, etiquette, Zone(107, 73, 344, 19), gris, Texte);
      using (Pen pen = new Pen(bord)) g.DrawLine(pen, S(26), S(115), S(454), S(115));
      Rectangle barre = Zone(26, 167, 428, 7);
      using (GraphicsPath p = Arrondi(barre, S(4)))
      using (var b = new SolidBrush(piste)) g.FillPath(b, p);
    }
    return bm;
  }
  protected void AfficherProgression(float valeur, string message) {
    message = message ?? "";
    if (message == etape && (valeur == pourcent || (valeur < 100f && Math.Abs(valeur - pourcent) < 0.07f))) return;
    if (message != etape) AccessibleDescription = message;
    pourcent = valeur; etape = message;
    Invalidate(Zone(22, 129, 438, 51));
  }
  protected void AfficherTemps(double ecoule, bool longAttente) {
    int nouveau = Math.Max(0, (int)ecoule);
    if (nouveau == secondes && longAttente == attenteLongue) return;
    secondes = nouveau; attenteLongue = longAttente;
    Invalidate(Zone(22, 184, 438, 22));
  }
  protected override void OnHandleCreated(EventArgs e) {
    base.OnHandleCreated(e);
    LkIdentiteAppli.EnregistrerFenetre(Handle, racine);
    try { int v = 2; DwmSetWindowAttribute(Handle, 33, ref v, 4); } catch { }
  }
  protected override void OnPaintBackground(PaintEventArgs e) { }
  protected override void OnPaint(PaintEventArgs e) {
    if (decor == null) decor = CreerDecor();
    Graphics g = e.Graphics; g.DrawImageUnscaled(decor, 0, 0);
    g.SmoothingMode = SmoothingMode.AntiAlias;
    TextRenderer.DrawText(g, etape, status, Zone(25, 131, 350, 28), texte, Texte);
    TextRenderer.DrawText(g, Math.Min(100, (int)pourcent) + " %", nombre, Zone(374, 131, 80, 28), acc,
      TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding);
    Rectangle barre = Zone(26, 167, 428, 7);
    float avance = barre.Width * pourcent / 100f;
    if (avance >= 1) {
      using (GraphicsPath p = Arrondi(new RectangleF(barre.X, barre.Y, avance, barre.Height), S(4)))
      using (var b = new LinearGradientBrush(barre, debut, fin, 0f)) g.FillPath(b, p);
    }
    if (secondes >= 0) TextRenderer.DrawText(g, FormaterTemps(secondes, anglais), etiquette, Zone(279, 184, 175, 22), gris,
      TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix);
    if (attenteLongue) TextRenderer.DrawText(g, anglais ? "This step is taking longer…" : "Cette étape prend du temps…", etiquette, Zone(25, 184, 253, 22), attente, Texte);
    ImageDessinee = true;
    base.OnPaint(e);
  }
  protected override void Dispose(bool disposing) {
    if (disposing) {
      if (decor != null) { decor.Dispose(); decor = null; }
      if (iconeFenetre != null) iconeFenetre.Dispose();
      titre.Dispose(); etiquette.Dispose(); status.Dispose(); nombre.Dispose();
    }
    base.Dispose(disposing);
  }
}

internal sealed class EtatChargement {
  internal readonly float Pct;
  internal readonly string Etape;
  internal readonly bool Termine;
  internal EtatChargement(float pct, string etape, bool termine) { Pct = pct; Etape = etape; Termine = termine; }
}

public static class LkChargement {
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  static readonly object verrou = new object();
  static readonly ManualResetEventSlim lance = new ManualResetEventSlim(false);
  static Thread fil;
  internal static volatile EtatChargement Etat = new EtatChargement(0, "", false);
  internal static volatile bool Ferme, Pret, Visible;
  internal static volatile IntPtr Hwnd;
  public static volatile string DerniereErreur = "";

  // Signature conservee pour le chargement depuis les versions precedentes.
  public static bool Start(bool clair, string version, string racine, string etape, float pct, float max) {
    return Start(clair, version, racine, etape, pct, max, false);
  }
  public static bool Start(bool clair, string version, string racine, string etape, float pct, float max, bool reduit) {
    return Start(clair, version, racine, etape, pct, max, reduit, CultureInfo.CurrentUICulture.TwoLetterISOLanguageName != "fr");
  }
  public static bool Start(bool clair, string version, string racine, string etape, float pct, float max, bool reduit, bool anglais) {
    lock (verrou) {
      if (fil != null && fil.IsAlive) return Active;
      DerniereErreur = "";
      Etat = new EtatChargement(float.IsNaN(pct) ? 0 : Math.Max(0, Math.Min(pct, 99f)), etape ?? "", false);
      Ferme = Pret = Visible = false;
      lance.Reset();
      try {
        try { SetProcessDPIAware(); } catch { }
        fil = new Thread(() => Executer(clair, version, racine, reduit, anglais)); fil.IsBackground = true; fil.Name = "LkChargement";
        fil.SetApartmentState(ApartmentState.STA); fil.Start();
      } catch (Exception ex) { DerniereErreur = ex.Message; return false; }
    }
    if (lance.Wait(1200) && Active) return true;
    if (DerniereErreur.Length == 0) DerniereErreur = "La fenêtre de chargement n'a pas répondu.";
    Close();
    return false;
  }
  static void Executer(bool clair, string version, string racine, bool reduit, bool anglais) {
    try {
      using (var ecran = new LkEcranChargement(clair, version, racine, LkSurfaceChargement.ReduireMouvement(reduit), anglais)) {
        if (!Ferme) Application.Run(ecran);
      }
    } catch (Exception ex) { DerniereErreur = ex.Message; }
    finally { Hwnd = IntPtr.Zero; Visible = false; lance.Set(); }
  }
  internal static void Affiche() {
    lock (verrou) {
      if (Ferme) return;
      Visible = true;
    }
    lance.Set();
    SignalerLanceur();
  }
  public static void SignalerLanceur() {
    Guid id;
    if (!Guid.TryParseExact(Environment.GetEnvironmentVariable("LK_SPLASH_READY"), "N", out id)) return;
    try {
      using (EventWaitHandle relai = EventWaitHandle.OpenExisting(@"Local\LuKZyR-Chargement-" + id.ToString("N"))) relai.Set();
    } catch { }
  }
  public static void Step(float pct, float max, string etape) {
    if (float.IsNaN(pct) || float.IsInfinity(pct)) return;
    lock (verrou) {
      EtatChargement avant = Etat;
      if (!avant.Termine && pct >= avant.Pct) Etat = new EtatChargement(Math.Min(99f, pct), etape ?? avant.Etape, false);
    }
  }
  public static void Finish(string etape) {
    lock (verrou) {
      EtatChargement avant = Etat;
      if (!avant.Termine || etape != null) Etat = new EtatChargement(100, etape ?? avant.Etape, true);
    }
  }
  public static void Ready() { Finish(null); Pret = true; SignalerLanceur(); }
  public static void Close() {
    lock (verrou) { Ferme = true; }
    IntPtr h = Hwnd;
    if (h != IntPtr.Zero) { try { PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); } catch { } }
  }
  public static bool Active { get { return Visible && !Ferme; } }
}

sealed class LkEcranChargement : LkSurfaceChargement {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int InternalGetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  readonly Stopwatch horloge = Stopwatch.StartNew();
  readonly System.Windows.Forms.Timer minuteur = new System.Windows.Forms.Timer();
  readonly ProgressionChargement progression;
  readonly bool reduit;
  readonly double ageInitial;
  readonly uint pid = (uint)Process.GetCurrentProcess().Id;
  double precedent, verification, changement, fin = -1, fondu = -1;
  EtatChargement dernierEtat;

  internal LkEcranChargement(bool clair, string version, string racine, bool reduit, bool anglais) : base(clair, version, racine, anglais) {
    this.reduit = reduit;
    dernierEtat = LkChargement.Etat;
    progression = new ProgressionChargement(dernierEtat.Pct);
    Text = "LuKZyR Optimisation - chargement";
    ReprendrePosition(Environment.GetEnvironmentVariable("LK_SPLASH_POSITION"));
    ageInitial = Math.Max(0, TempsLanceur(Environment.GetEnvironmentVariable("LK_SPLASH_DEBUT")) - horloge.Elapsed.TotalSeconds);
    AfficherProgression(progression.Valeur, dernierEtat.Etape);
    AfficherTemps(ageInitial + horloge.Elapsed.TotalSeconds, false);
    minuteur.Interval = 100; minuteur.Tick += Tick;
  }
  protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); LkChargement.Hwnd = Handle; }
  protected override void OnShown(EventArgs e) {
    base.OnShown(e);
    if (LkChargement.Ferme) { BeginInvoke((MethodInvoker)Close); return; }
    Refresh();
    if (ImageDessinee) LkChargement.Affiche();
    minuteur.Start();
  }
  bool FenetrePrincipaleVisible() {
    bool visible = false;
    try {
      EnumWindows(delegate (IntPtr h, IntPtr l) {
        uint p; GetWindowThreadProcessId(h, out p);
        if (p != pid || h == Handle || !IsWindowVisible(h)) return true;
        var titre = new StringBuilder(64); InternalGetWindowText(h, titre, titre.Capacity);
        if (titre.ToString() != "LuKZyR Optimisation") return true;
        visible = true; return false;
      }, IntPtr.Zero);
    } catch { }
    return visible;
  }
  void Tick(object o, EventArgs e) {
    try {
      double t = horloge.Elapsed.TotalSeconds;
      if (LkChargement.Ferme || t > 600) { Close(); return; }
      EtatChargement etat = LkChargement.Etat;
      if (!etat.Termine && t - verification >= 0.5) {
        verification = t;
        if (FenetrePrincipaleVisible()) { LkChargement.Finish(null); etat = LkChargement.Etat; }
      }
      if (etat.Pct != dernierEtat.Pct || etat.Etape != dernierEtat.Etape) changement = t;
      dernierEtat = etat;
      if (etat.Termine && fin < 0) fin = t;
      progression.Avancer(etat.Pct, t - precedent, reduit);
      precedent = t;
      AfficherProgression(progression.Valeur, etat.Etape);
      AfficherTemps(ageInitial + (fin < 0 ? t : fin), fin < 0 && t - changement >= 12);
      int intervalle = ProgressionChargement.Intervalle(progression.Valeur, etat.Pct, fin >= 0);
      if (minuteur.Interval != intervalle) minuteur.Interval = intervalle;
      if (fin < 0) return;
      if (t - fin > 3) { Close(); return; }
      if (fondu < 0 && progression.Valeur >= 100 && (LkChargement.Pret || t - fin > 1.5)) {
        if (reduit) { Close(); return; }
        fondu = t;
      }
      if (fondu >= 0) {
        double opacite = ProgressionChargement.Opacite(t - fondu);
        if (opacite <= 0.02) { Close(); return; }
        Opacity = opacite;
      }
    } catch (Exception ex) { LkChargement.DerniereErreur = ex.Message; Close(); }
  }
  protected override void Dispose(bool disposing) {
    if (disposing) minuteur.Dispose();
    base.Dispose(disposing);
  }
}
