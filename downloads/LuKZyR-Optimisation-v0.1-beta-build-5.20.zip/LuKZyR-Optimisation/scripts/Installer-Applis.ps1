﻿param([string[]]$Apps = @("Discord","Steam","Epic Games","Brave","Spotify","Ubisoft Connect","Rockstar Games"), [switch]$SansQuestion, [switch]$NonInteractif, [switch]$MajTout)
# Installation des applis via winget (sources officielles) : Discord, Steam, Epic Games, Brave, Spotify, Ubisoft Connect,
# Rockstar Games, EA app, Battle.net, GOG Galaxy, 7-Zip, VLC, OBS Studio (sans paramètre : les 7 premières)
$ErrorActionPreference = "SilentlyContinue"
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # v5.6 : relance en administrateur AVEC les mêmes paramètres, attend la fin et renvoie son code ; UAC refusé = code 1
    $relance = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
    foreach ($p in $PSBoundParameters.GetEnumerator()) {
      if ($p.Value -is [switch]) { if ($p.Value.IsPresent) { $relance += "-$($p.Key)" } }
      else { $relance += "-$($p.Key)"; $relance += "`"$(@($p.Value) -join ',')`"" }
    }
    try { $pr = Start-Process powershell -ArgumentList ($relance -join ' ') -Verb RunAs -Wait -PassThru -ErrorAction Stop; exit $pr.ExitCode }
    catch { Write-Host "Droits administrateur refusés : rien n'a été modifié." -ForegroundColor Red; exit 1 }
}
if ($NonInteractif) { [Console]::OutputEncoding = New-Object Text.UTF8Encoding $false; $SansQuestion = $true }
# -Apps "Discord,Epic Games" (passé en une seule chaîne par -File) -> liste
$Apps = @($Apps | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim(" '`"") } | Where-Object { $_ })
Write-Host "`n==> Installation des applications" -ForegroundColor Cyan
# v5.6 : chemin complet de winget (l'alias WindowsApps n'est pas toujours trouvé en administrateur)
function Trouver-Winget {
  $c = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($c -and $c.Source -and (Test-Path $c.Source)) { return $c.Source }
  $alias = Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\winget.exe"
  if (Test-Path $alias) { return $alias }
  $arch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
  if ($arch -eq "AMD64") { $arch = "x64" }
  $d = Get-ChildItem "$env:ProgramFiles\WindowsApps\Microsoft.DesktopAppInstaller_*_${arch}__8wekyb3d8bbwe\winget.exe" -ErrorAction SilentlyContinue | Sort-Object { try { [version](($_.Directory.Name -split '_')[1]) } catch { [version]"0.0" } } -Descending | Select-Object -First 1
  if ($d) { return $d.FullName }
  return $null
}
$winget = Trouver-Winget
if (-not $winget) {
    Write-Host "winget est absent : installe « Programme d'installation d'application » (App Installer) depuis le Microsoft Store, puis relance." -ForegroundColor Red
    if (-not $NonInteractif) { Read-Host "Entrée pour fermer" }
    exit 1
}
& $winget source update --disable-interactivity 2>&1 | Out-Null
$applis = [ordered]@{
  "Discord"     = "Discord.Discord"
  "Steam"       = "Valve.Steam"
  "Epic Games"  = "EpicGames.EpicGamesLauncher"
  "Brave"       = "Brave.Brave"
  "Spotify"     = "Spotify.Spotify"
  "Ubisoft Connect" = "Ubisoft.Connect"
  "Rockstar Games"  = "RockstarGames.Launcher"
  "EA app"      = "ElectronicArts.EADesktop"
  "Battle.net"  = "Blizzard.BattleNet"
  "GOG Galaxy"  = "GOG.Galaxy"
  "7-Zip"       = "7zip.7zip"
  "VLC"         = "VideoLAN.VLC"
  "OBS Studio"  = "OBSProject.OBSStudio"
}
# Options supplémentaires par appli : le paquet Battle.net exige un dossier d'installation (InstallLocationRequired)
$options = @{
  "Battle.net" = @("--location", "${env:ProgramFiles(x86)}\Battle.net")
}
$echecs = 0
foreach ($nom in $applis.Keys) {
  if ($Apps -notcontains $nom) { continue }
  $id = $applis[$nom]
  $resultatListe = & $winget list --id $id --exact --source winget --accept-source-agreements --disable-interactivity 2>&1
  if ($LASTEXITCODE -eq 0 -and ($resultatListe | Select-String ("\s" + [regex]::Escape($id) + "\s"))) {
    Write-Host " - $nom déjà installé." -ForegroundColor Yellow
    continue
  }
  Write-Host " - Installation de $nom..."
  if ($nom -eq "Spotify") {
    # L'installeur de Spotify refuse de tourner en administrateur : on le relance avec des droits normaux
    $spExe = Join-Path $env:APPDATA "Spotify\Spotify.exe"
    if (Test-Path $spExe) { Write-Host "   Spotify déjà installé." -ForegroundColor Yellow; continue }
    $cmd = Join-Path $env:TEMP "lukzyr-spotify.cmd"
    $res = Join-Path $env:TEMP "lukzyr-spotify.log"
    $dem = Join-Path $env:TEMP "lukzyr-spotify.start"
    Remove-Item $res, $dem -Force -ErrorAction SilentlyContinue
    # v5.6 : le script note qu'il a bien démarré (sinon l'Explorateur ne l'a pas lancé), puis le code de winget
    # v5.14 : chemin COMPLET de winget (comme partout ailleurs) : d'abord l'alias de l'utilisateur qui lance le script
    # (droits normaux), sinon le chemin trouvé ici ; plus de « winget » nu qui dépendait du PATH
    $wgCmd = "$winget" -replace '%', '%%'
    Set-Content -Path $cmd -Encoding Oem -Value "@echo off`r`necho 1 > `"$dem`"`r`nset `"WG=%LOCALAPPDATA%\Microsoft\WindowsApps\winget.exe`"`r`nif not exist `"%WG%`" set `"WG=$wgCmd`"`r`n`"%WG%`" install --id Spotify.Spotify --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity`r`necho CODE=%ERRORLEVEL% > `"$res`"`r`nexit"
    $lua = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue).EnableLUA
    if ($lua -eq 0) {
      # Contrôle de compte (UAC) désactivé : l'Explorateur est lui aussi administrateur -> jeton restreint
      Start-Process runas.exe -ArgumentList "/trustlevel:0x20000 `"$cmd`"" -WindowStyle Hidden
    } else {
      # Cas normal : l'Explorateur tourne avec des droits normaux
      Start-Process explorer.exe -ArgumentList "`"$cmd`""
    }
    $t = 0
    # 1 min pour démarrer, puis 5 min max pour l'installation ; seul le code de winget fait foi
    while (-not (Test-Path $res) -and $t -lt 360) {
      Start-Sleep -Seconds 5; $t += 5
      if ($t -ge 60 -and -not (Test-Path $dem)) { break }
    }
    $lance = Test-Path $dem
    $code = "$(Get-Content $res -Raw -ErrorAction SilentlyContinue)" -replace '(?s)^\D*?(-?\d+).*', '$1'
    if ((Test-Path $spExe) -and -not (Test-Path $res)) { Start-Sleep -Seconds 10; $code = "$(Get-Content $res -Raw -ErrorAction SilentlyContinue)" -replace '(?s)^\D*?(-?\d+).*', '$1' }
    Remove-Item $cmd, $res, $dem -Force -ErrorAction SilentlyContinue
    if (-not $lance) { Write-Host "   Échec pour Spotify : l'installation n'a pas pu démarrer en droits normaux. Installe-le depuis spotify.com." -ForegroundColor Red; $echecs++ }
    elseif ("$code".Trim() -eq "0" -or ((Test-Path $spExe) -and -not "$code".Trim())) { Write-Host "   Spotify installé." -ForegroundColor Green }
    elseif ("$code".Trim()) { Write-Host "   Échec pour Spotify (code $("$code".Trim())), installe-le depuis spotify.com." -ForegroundColor Red; $echecs++ }
    else { Write-Host "   Spotify : pas de réponse au bout de 6 min (l'installation continue peut-être). Vérifie, sinon installe-le depuis spotify.com." -ForegroundColor Yellow; $echecs++ }
    continue
  }
  $extra = @($options[$nom] | Where-Object { $_ })
  & $winget install --id $id --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity @extra 2>&1 |
    ForEach-Object { "$_" } | Where-Object { $_ -match '[A-Za-z]{3}' -and $_ -notmatch '[█▒]' } | ForEach-Object { Write-Host "   $($_.Trim())" }
  if ($LASTEXITCODE -eq 0) { Write-Host "   $nom installé." -ForegroundColor Green } else { Write-Host "   Échec pour $nom (code $LASTEXITCODE), installe-le à la main." -ForegroundColor Red; $echecs++ }
}
if ($SansQuestion) { $r = if ($MajTout) { "o" } else { "n" } } else { $r = Read-Host "`nMettre aussi à jour toutes tes autres applis avec winget ? (o/n)" }
if ($r -eq "o") {
  Write-Host "`n==> Mise à jour des autres applications" -ForegroundColor Cyan
  & $winget upgrade --all --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 |
    ForEach-Object { "$_" } | Where-Object { $_ -match '[A-Za-z]{3}' -and $_ -notmatch '[█▒]' } | ForEach-Object { Write-Host "   $($_.Trim())" }
  if ($LASTEXITCODE -ne 0) { Write-Host "   Certaines mises à jour ont échoué (code $LASTEXITCODE)." -ForegroundColor Red; $echecs++ }
}
if ($echecs) { Write-Host "`nApplications terminées avec $echecs échec(s)." -ForegroundColor Red }
else { Write-Host "`nApplications terminées." -ForegroundColor Green }
if (-not $NonInteractif -and -not $SansQuestion) { Read-Host "Appuie sur Entrée pour fermer" }
# v5.6 : code 1 dès qu'une installation a échoué (l'interface le signale dans le résumé)
if ($echecs) { exit 1 } else { exit 0 }
