﻿// Ecran de chargement WinForms partage entre le lanceur et PowerShell.
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#if !LK_LANCEUR
[assembly: AssemblyTitle("LuKZyR Optimisation - chargement")]
[assembly: AssemblyProduct("LuKZyR Optimisation")]
[assembly: AssemblyCompany("Lukzyr")]
[assembly: AssemblyCopyright("Copyright © 2026 Lukzyr")]
[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.0")]
[assembly: AssemblyInformationalVersion("0.2.0-beta")]
#endif

internal sealed class ProgressionChargement {
  internal float Valeur { get; private set; }
  internal ProgressionChargement(float valeur) { Valeur = valeur; }
  internal void Avancer(float cible, double secondes, bool reduit) {
    cible = Math.Max(Valeur, Math.Min(cible, 100f));
    Valeur = reduit ? cible : Valeur + (cible - Valeur) * (float)(1 - Math.Exp(-15 * Math.Max(0, secondes)));
    if (cible - Valeur < 0.15f) Valeur = cible;
  }
  internal static double Opacite(double secondes) {
    double reste = Math.Max(0, Math.Min(1, 1 - secondes / 0.16));
    return reste * reste * (3 - 2 * reste);
  }
}

internal class LkSurfaceChargement : Form {
  [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);
  [DllImport("user32.dll")] static extern bool SystemParametersInfo(int action, int param, ref int valeur, int flags);
  readonly string racine, version;
  readonly Color fond, bord, texte, gris, acc, piste, puce;
  readonly Color debut, fin;
  readonly float s;
  readonly Font titre, etiquette, status, nombre;
  readonly Icon iconeFenetre;
  Bitmap decor;
  float pourcent;
  string etape = "";

  internal static bool ReduireMouvement(bool preference) {
    int active = 1;
    try { if (SystemParametersInfo(0x1042, 0, ref active, 0) && active == 0) return true; } catch { }
    return preference;
  }
  internal LkSurfaceChargement(bool clair, string version, string racine) {
    this.racine = racine; this.version = version;
    fond = C(clair ? "#f5f7fc" : "#141723"); bord = C(clair ? "#d8deeb" : "#303851");
    texte = C(clair ? "#171c30" : "#f2f4ff"); gris = C(clair ? "#475371" : "#aab3ca");
    acc = C(clair ? "#5835b4" : "#c6b6ff"); piste = C(clair ? "#dce1ee" : "#303652");
    puce = C(clair ? "#ebe5ff" : "#282440"); debut = C(clair ? "#4d54c8" : "#69bcf6"); fin = C(clair ? "#704adc" : "#ae8cff");
    using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) {
      Rectangle bureau = Screen.PrimaryScreen.WorkingArea;
      s = Math.Min(Math.Max(1f, g.DpiX / 96f), Math.Min(bureau.Width / 500f, bureau.Height / 238f));
    }
    FormBorderStyle = FormBorderStyle.None; StartPosition = FormStartPosition.CenterScreen;
    AutoScaleMode = AutoScaleMode.None; ClientSize = new Size(S(480), S(210)); BackColor = fond;
    DoubleBuffered = true; ShowInTaskbar = true;
    titre = Police(25, FontStyle.Bold);
    etiquette = Police(12, FontStyle.Regular);
    status = Police(14, FontStyle.Regular);
    nombre = Police(14, FontStyle.Bold);
    try {
      string chemin = Path.Combine(racine, "assets", "lukzyr.ico");
      if (File.Exists(chemin)) { iconeFenetre = new Icon(chemin); Icon = iconeFenetre; }
    } catch { }
  }
  static Color C(string h) { return ColorTranslator.FromHtml(h); }
  int S(float n) { return (int)Math.Round(n * s); }
  Rectangle Zone(int x, int y, int w, int h) { return new Rectangle(S(x), S(y), S(w), S(h)); }
  Font Police(float taille, FontStyle style) { return new Font("Segoe UI", taille * s, style, GraphicsUnit.Pixel); }
  static GraphicsPath Arrondi(RectangleF r, float rayon) {
    GraphicsPath p = new GraphicsPath();
    float d = Math.Min(rayon * 2, Math.Min(r.Width, r.Height));
    if (d < 1) { p.AddRectangle(r); return p; }
    p.AddArc(r.Left, r.Top, d, d, 180, 90);
    p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
    p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
    p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
    p.CloseFigure(); return p;
  }
  const TextFormatFlags Texte = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
  Bitmap CreerDecor() {
    Bitmap bm = new Bitmap(ClientSize.Width, ClientSize.Height);
    using (Graphics g = Graphics.FromImage(bm)) {
      g.Clear(fond); g.SmoothingMode = SmoothingMode.AntiAlias;
      using (Pen pen = new Pen(bord)) g.DrawRectangle(pen, 0, 0, bm.Width - 1, bm.Height - 1);
      Rectangle bande = Zone(1, 1, 478, 4);
      using (var b = new LinearGradientBrush(bande, debut, fin, 0f)) g.FillRectangle(b, bande);
      using (GraphicsPath p = Arrondi(Zone(26, 31, 64, 64), S(16)))
      using (var b = new SolidBrush(puce)) g.FillPath(b, p);
      try {
        using (Image logo = Image.FromFile(Path.Combine(racine, "assets", "logo.png"))) {
          g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.DrawImage(logo, Zone(38, 43, 40, 40));
        }
      } catch { TextRenderer.DrawText(g, "L", titre, Zone(26, 31, 64, 64), acc, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine); }
      TextRenderer.DrawText(g, "LuKZyR Optimisation", titre, Zone(106, 35, 350, 36), texte, Texte);
      TextRenderer.DrawText(g, version, etiquette, Zone(107, 73, 344, 19), gris, Texte);
      using (Pen pen = new Pen(bord)) g.DrawLine(pen, S(26), S(115), S(454), S(115));
      Rectangle barre = Zone(26, 167, 428, 7);
      using (GraphicsPath p = Arrondi(barre, S(4)))
      using (var b = new SolidBrush(piste)) g.FillPath(b, p);
    }
    return bm;
  }
  protected void AfficherProgression(float valeur, string message) {
    if (Math.Abs(valeur - pourcent) < 0.07f && message == etape && valeur < 100f) return;
    if (valeur == pourcent && message == etape) return;
    pourcent = valeur; etape = message ?? "";
    Invalidate(Zone(22, 129, 438, 52));
  }
  protected override void OnHandleCreated(EventArgs e) {
    base.OnHandleCreated(e);
    try { int v = 2; DwmSetWindowAttribute(Handle, 33, ref v, 4); } catch { }
  }
  protected override void OnPaintBackground(PaintEventArgs e) { }
  protected override void OnPaint(PaintEventArgs e) {
    if (decor == null) decor = CreerDecor();
    Graphics g = e.Graphics; g.DrawImageUnscaled(decor, 0, 0);
    g.SmoothingMode = SmoothingMode.AntiAlias;
    TextRenderer.DrawText(g, etape, status, Zone(25, 131, 350, 28), texte, Texte);
    TextRenderer.DrawText(g, Math.Min(100, (int)pourcent) + " %", nombre, Zone(374, 131, 80, 28), acc,
      TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding);
    Rectangle barre = Zone(26, 167, 428, 7);
    float avance = barre.Width * pourcent / 100f;
    if (avance >= 1) {
      using (GraphicsPath p = Arrondi(new RectangleF(barre.X, barre.Y, avance, barre.Height), S(4)))
      using (var b = new LinearGradientBrush(barre, debut, fin, 0f)) g.FillPath(b, p);
    }
    base.OnPaint(e);
  }
  protected override void Dispose(bool disposing) {
    if (disposing) {
      if (decor != null) { decor.Dispose(); decor = null; }
      if (iconeFenetre != null) iconeFenetre.Dispose();
      titre.Dispose(); etiquette.Dispose(); status.Dispose(); nombre.Dispose();
    }
    base.Dispose(disposing);
  }
}

public static class LkChargement {
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  static readonly object verrou = new object();
  static readonly ManualResetEventSlim lance = new ManualResetEventSlim(false);
  static Thread fil;
  internal static volatile float Pct;
  internal static volatile string Etape = "";
  internal static volatile bool Fin, Ferme, Pret, Visible;
  internal static volatile IntPtr Hwnd;
  public static volatile string DerniereErreur = "";

  // Signature conservee pour le chargement depuis les versions precedentes.
  public static bool Start(bool clair, string version, string racine, string etape, float pct, float max) {
    return Start(clair, version, racine, etape, pct, max, false);
  }
  public static bool Start(bool clair, string version, string racine, string etape, float pct, float max, bool reduit) {
    lock (verrou) {
      if (fil != null && fil.IsAlive) return Visible;
      DerniereErreur = ""; Etape = etape ?? ""; Pct = Math.Max(0, Math.Min(pct, 99f));
      Fin = Ferme = Pret = Visible = false;
      lance.Reset();
      try {
        try { SetProcessDPIAware(); } catch { }
        fil = new Thread(() => Executer(clair, version, racine, reduit)); fil.IsBackground = true; fil.Name = "LkChargement";
        fil.SetApartmentState(ApartmentState.STA); fil.Start();
      } catch (Exception ex) { DerniereErreur = ex.Message; return false; }
    }
    if (lance.Wait(1200) && Visible) return true;
    if (DerniereErreur.Length == 0) DerniereErreur = "La fenêtre de chargement n'a pas répondu.";
    Close();
    return false;
  }
  static void Executer(bool clair, string version, string racine, bool reduit) {
    try {
      using (var ecran = new LkEcranChargement(clair, version, racine, LkSurfaceChargement.ReduireMouvement(reduit))) {
        if (!Ferme) Application.Run(ecran);
      }
    } catch (Exception ex) { DerniereErreur = ex.Message; }
    finally { Hwnd = IntPtr.Zero; Visible = false; lance.Set(); }
  }
  internal static void Affiche() {
    Visible = true;
    lance.Set();
    SignalerLanceur();
  }
  public static void SignalerLanceur() {
    Guid id;
    if (!Guid.TryParseExact(Environment.GetEnvironmentVariable("LK_SPLASH_READY"), "N", out id)) return;
    try {
      using (EventWaitHandle relai = EventWaitHandle.OpenExisting(@"Local\LuKZyR-Chargement-" + id.ToString("N"))) relai.Set();
    } catch { }
  }
  public static void Step(float pct, float max, string etape) {
    if (Fin) return;
    if (pct >= Pct) { if (etape != null) Etape = etape; Pct = Math.Min(99f, pct); }
  }
  public static void Finish(string etape) { if (etape != null) Etape = etape; Pct = 100; Fin = true; }
  public static void Ready() { if (!Fin) Finish(null); Pret = true; SignalerLanceur(); }
  public static void Close() {
    Ferme = true;
    IntPtr h = Hwnd;
    if (h != IntPtr.Zero) { try { PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); } catch { } }
  }
  public static bool Active { get { return Visible && !Ferme; } }
}

sealed class LkEcranChargement : LkSurfaceChargement {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int InternalGetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  readonly Stopwatch horloge = Stopwatch.StartNew();
  readonly System.Windows.Forms.Timer minuteur = new System.Windows.Forms.Timer();
  readonly ProgressionChargement progression;
  readonly bool reduit;
  readonly uint pid = (uint)Process.GetCurrentProcess().Id;
  double precedent, verification, fin = -1, fondu = -1;

  internal LkEcranChargement(bool clair, string version, string racine, bool reduit) : base(clair, version, racine) {
    this.reduit = reduit; progression = new ProgressionChargement(LkChargement.Pct);
    Text = "LuKZyR Optimisation - chargement";
    AfficherProgression(progression.Valeur, LkChargement.Etape);
    minuteur.Interval = 30; minuteur.Tick += Tick;
  }
  protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); LkChargement.Hwnd = Handle; }
  protected override void OnShown(EventArgs e) {
    base.OnShown(e);
    if (LkChargement.Ferme) { BeginInvoke((MethodInvoker)Close); return; }
    Update();
    LkChargement.Affiche(); minuteur.Start();
  }
  bool FenetrePrincipaleVisible() {
    bool visible = false;
    try {
      EnumWindows(delegate (IntPtr h, IntPtr l) {
        uint p; GetWindowThreadProcessId(h, out p);
        if (p != pid || h == Handle || !IsWindowVisible(h)) return true;
        var titre = new StringBuilder(64); InternalGetWindowText(h, titre, titre.Capacity);
        if (titre.ToString() != "LuKZyR Optimisation") return true;
        visible = true; return false;
      }, IntPtr.Zero);
    } catch { }
    return visible;
  }
  void Tick(object o, EventArgs e) {
    try {
      double t = horloge.Elapsed.TotalSeconds;
      if (LkChargement.Ferme || t > 600) { Close(); return; }
      if (!LkChargement.Fin && t - verification >= 0.5) {
        verification = t;
        if (FenetrePrincipaleVisible()) LkChargement.Finish(null);
      }
      if (LkChargement.Fin && fin < 0) fin = t;
      progression.Avancer(LkChargement.Pct, t - precedent, reduit);
      precedent = t;
      AfficherProgression(progression.Valeur, LkChargement.Etape);
      if (fin < 0) return;
      if (t - fin > 3) { Close(); return; }
      if (fondu < 0 && progression.Valeur >= 100 && (LkChargement.Pret || t - fin > 1.5)) {
        if (reduit) { Close(); return; }
        fondu = t;
      }
      if (fondu >= 0) {
        double opacite = ProgressionChargement.Opacite(t - fondu);
        if (opacite <= 0.02) { Close(); return; }
        Opacity = opacite;
      }
    } catch (Exception ex) { LkChargement.DerniereErreur = ex.Message; Close(); }
  }
  protected override void Dispose(bool disposing) {
    if (disposing) minuteur.Dispose();
    base.Dispose(disposing);
  }
}
