﻿# LuKZyR Optimisation - traductions de l'interface (français -> anglais)
# Clé = texte français affiché, valeur = texte anglais. Un texte absent reste en français.
$EN = @{
  # Barre latérale et pages
  "Accueil" = "Home"; "Pilotes" = "Drivers"; "Nettoyage" = "Cleanup"; "Applications" = "Apps"; "Optimisation" = "Optimization"
  "Démarrage" = "Startup"; "Réseau" = "Network"; "Santé" = "Health"; "Outils" = "Tools"; "BIOS" = "BIOS"; "Journal" = "Log"
  "O P T I M I S A T I O N" = "O P T I M I Z A T I O N"
  "Matériel détecté sur ce PC." = "Hardware detected on this PC."
  "Pilotes officiels des fabricants de tes composants." = "Official drivers from your components' manufacturers."
  "Aucun pilote spécifique détecté sur ce PC." = "No specific driver detected on this PC."
  "Supprime ce qui ralentit Windows, sans rien casser." = "Removes what slows Windows down, without breaking anything."
  "Installées depuis leurs sources officielles (winget)." = "Installed from their official sources (winget)."
  "Active ce que tu veux, puis clique sur Appliquer." = "Turn on what you want, then click Apply."
  "Applis lancées avec Windows : désactive celles qui ralentissent (réversible)." = "Apps launched with Windows: turn off the ones that slow you down (reversible)."
  "Choisis ton DNS et vide le cache DNS." = "Choose your DNS and flush the DNS cache."
  "DNS, cache DNS et bande passante des mises à jour Windows." = "DNS, DNS cache, and Windows Update bandwidth."
  "Jeu, affichage, alimentation et démarrage. Tout est annulable avec « Tout annuler »." = "Gaming, display, power, and startup. Undo these changes with `"Undo everything`"."
  "État des disques, de l'espace libre, de la température et de la mémoire." = "Disk health, free space, temperature and memory."
  "Raccourcis, « Tout annuler » et réglages de l'appli." = "Shortcuts, `"Undo everything`" and app settings."
  "Guide BIOS" = "BIOS guide"; "Personnalisé pour {0}." = "Personalised for {0} (guide text in French)."
  "Tout ce qui a été fait, en direct." = "Everything that was done, live."
  # Statistiques et accueil
  "Go libres" = "GB free"; "Non détecté" = "Not detected"; "Non détectée" = "Not detected"; "Non communiquée" = "Not reported"
  "PROCESSEUR" = "PROCESSOR"; "CARTE GRAPHIQUE" = "GRAPHICS CARD"; "CARTE MÈRE" = "MOTHERBOARD"; "MÉMOIRE" = "MEMORY"; "STOCKAGE" = "STORAGE"; "SYSTÈME" = "SYSTEM"
  # Pilotes
  "Pilotes chipset AMD" = "AMD chipset drivers"; "Pilote NVIDIA (NVIDIA App)" = "NVIDIA driver (NVIDIA App)"; "Pilote AMD Adrenalin" = "AMD Adrenalin driver"; "Pilote graphique Intel" = "Intel graphics driver"
  "Ouvre la page officielle AMD (chipset Ryzen)." = "Opens the official AMD page (Ryzen chipset)."
  "Chipset, Wi-Fi, iGPU. Installé automatiquement depuis Intel (winget)." = "Chipset, Wi-Fi, iGPU. Installed automatically from Intel (winget)."
  "Pour {0}. Ouvre la page officielle NVIDIA." = "For {0}. Opens the official NVIDIA page."
  "Pour {0}. Ouvre la page officielle AMD." = "For {0}. Opens the official AMD page."
  "Pour {0}. Installé automatiquement depuis Intel (winget)." = "For {0}. Installed automatically from Intel (winget)."
  "BIOS, LAN, audio : page support officielle MSI." = "BIOS, LAN, audio: official MSI support page."
  "BIOS, LAN, audio : page support officielle ASUS." = "BIOS, LAN, audio: official ASUS support page."
  "BIOS, LAN, audio : page support officielle Gigabyte." = "BIOS, LAN, audio: official Gigabyte support page."
  "BIOS, LAN, audio : page support officielle ASRock." = "BIOS, LAN, audio: official ASRock support page."
  "Recherche la page support du fabricant." = "Searches for the manufacturer's support page."
  "Firmware et santé des SSD Samsung (page officielle)." = "Samsung SSD firmware and health (official page)."
  "Firmware des SSD Crucial (page officielle)." = "Crucial SSD firmware (official page)."
  "Firmware des SSD WD / SanDisk (page officielle)." = "WD / SanDisk SSD firmware (official page)."
  "Firmware des SSD Kingston. Installé automatiquement (winget)." = "Kingston SSD firmware. Installed automatically (winget)."
  "Diagnostic des disques Seagate (page officielle)." = "Seagate disk diagnostics (official page)."
  # Nettoyage
  "Débloat Windows" = "Debloat Windows"
  "Applis préinstallées inutiles, pubs, Bing, widgets, télémétrie. Store, Xbox, Photos restent." = "Useless preinstalled apps, ads, Bing, widgets, telemetry. Store, Xbox, Photos stay."
  "Supprimer Copilot" = "Remove Copilot"; "Retire l'appli Copilot et masque son bouton." = "Removes the Copilot app and hides its button."
  "Désinstaller OneDrive" = "Uninstall OneDrive"; "Tes fichiers déjà synchronisés restent sur le PC." = "Your already synced files stay on the PC."
  "Désinstaller antivirus / VPN tiers" = "Uninstall third-party antivirus / VPN"
  "McAfee, Norton et ExpressVPN. Retire leur protection ou leur VPN." = "McAfee, Norton and ExpressVPN. Removes their protection or VPN."
  "Désinstallation de McAfee, Norton et ExpressVPN" = "Uninstall McAfee, Norton and ExpressVPN"
  "Désinstaller Microsoft Edge" = "Uninstall Microsoft Edge"; "Garde WebView2. Fait après l'installation de Brave." = "Keeps WebView2. Done after Brave is installed."
  # Applications
  "JEUX" = "GAMES"; "COMMUNICATION / MUSIQUE" = "COMMUNICATION / MUSIC"; "UTILITAIRES" = "UTILITIES"
  "La plus grande boutique de jeux PC." = "The biggest PC game store."
  "Jeux gratuits chaque semaine et Fortnite." = "Free games every week, and Fortnite."
  "Launcher des jeux Ubisoft (Assassin's Creed, Rainbow Six...)." = "Ubisoft games launcher (Assassin's Creed, Rainbow Six...)."
  "Launcher de GTA V, Red Dead Redemption 2..." = "Launcher for GTA V, Red Dead Redemption 2..."
  "Launcher des jeux EA (EA SPORTS FC, Battlefield, Les Sims...)." = "EA games launcher (EA SPORTS FC, Battlefield, The Sims...)."
  "Launcher Blizzard (Call of Duty, Diablo, Overwatch...)." = "Blizzard launcher (Call of Duty, Diablo, Overwatch...)."
  "Jeux sans DRM et bibliothèque de tous tes launchers." = "DRM-free games and a library of all your launchers."
  "Discussion vocale et texte pour jouer entre amis." = "Voice and text chat to play with friends."
  "Musique et podcasts en streaming." = "Music and podcast streaming."
  "Navigateur rapide avec bloqueur de pubs intégré." = "Fast browser with a built-in ad blocker."
  "Ouvre et crée les archives .zip, .7z, .rar." = "Opens and creates .zip, .7z, .rar archives."
  "Lit toutes les vidéos et musiques." = "Plays every video and music file."
  "Enregistrement et streaming de tes parties." = "Record and stream your games."
  "Mettre à jour les autres applis" = "Update other apps"; "Met à jour tout ce que winget sait gérer." = "Updates everything winget can handle."
  # Optimisation
  "Gaming max" = "Max gaming"; "Équilibré" = "Balanced"; "PC portable" = "Laptop"; "conseillé" = "recommended"
  "Plan d'alimentation Performances élevées" = "High performance power plan"; "Gain faible (0 à 2 %), un peu plus de chaleur. Ignoré sur PC portable." = "Small gain (0 to 2 %), a little more heat. Skipped on laptops."
  # v5.5 : nouveaux réglages, vérifications, animations
  "Optimisations des jeux en fenêtre" = "Optimizations for windowed games"; "Moins de latence en plein écran fenêtré, HDR auto possible." = "Lower latency in borderless windowed games, Auto HDR possible."
  "Optimisations VRR (FreeSync / G-Sync)" = "VRR optimizations (FreeSync / G-Sync)"; "Fréquence variable aussi pour les jeux qui ne la gèrent pas." = "Variable refresh rate even for games that don't support it."
  "Plan d'alimentation Utilisation normale" = "Balanced power plan"; "Conseillé pour Ryzen : mêmes performances en jeu, moins de chaleur." = "Advised for Ryzen: same gaming performance, less heat."
  "DÉMARRAGE ET ARRIÈRE-PLAN" = "STARTUP AND BACKGROUND"
  "Applis de démarrage sans délai" = "Startup apps without delay"; "Windows lance tes applis de démarrage sans attendre 10 secondes." = "Windows starts your startup apps without waiting 10 seconds."
  "Edge sans préchargement" = "Edge without preloading"; "Edge ne démarre plus avec Windows et ne reste plus ouvert une fois fermé." = "Edge no longer starts with Windows or stays open once closed."
  "Edge n'est pas installé : rien à régler." = "Edge is not installed: nothing to change."
  "Bloquer les applis du Store en arrière-plan" = "Block Store apps in the background"; "Un peu moins de mémoire utilisée. Certaines notifications peuvent arriver en retard." = "Slightly less memory used. Some notifications may arrive late."
  "Nettoyage des composants Windows" = "Windows component cleanup"; "Supprime les anciennes versions des composants (5 à 15 min). Mises à jour toujours désinstallables." = "Removes old component versions (5 to 15 min). Updates can still be uninstalled."
  "VÉRIFICATIONS (RIEN N'EST MODIFIÉ)" = "CHECKS (NOTHING IS CHANGED)"; "Lecture..." = "Reading..."; "Ouverture" = "Opening"
  "Fréquence de l'écran" = "Display refresh rate"; "Explications" = "Learn more"; "Ouvrir Adrenalin" = "Open Adrenalin"
  "Fréquence impossible à lire sur ce PC." = "Refresh rate can't be read on this PC."
  "Réglée à {0} Hz alors que l'écran accepte {1} Hz : à changer." = "Set to {0} Hz while the display accepts {1} Hz: change it."
  "Réglée à {0} Hz, le maximum proposé (rien à faire)." = "Set to {0} Hz, the highest offered (nothing to do)."
  "Resizable BAR / Smart Access Memory" = "Resizable BAR / Smart Access Memory"; "Radeon Anti-Lag" = "Radeon Anti-Lag"
  "Ne pas déranger en jeu" = "Do not disturb while gaming"; "Notifications coupées automatiquement quand un jeu est en plein écran." = "Notifications silenced automatically when a game is full screen."
  "Indexation de la recherche" = "Search indexing"; "Exclure tes dossiers de jeux de l'indexation évite des lectures disque inutiles." = "Excluding your game folders from indexing avoids useless disk reads."
  "Effets d'animation de Windows" = "Windows animation effects"; "Activés. Les couper rend Windows plus vif sur un PC lent." = "On. Turning them off makes Windows snappier on a slow PC."
  "Coupés (l'appli n'anime rien non plus)." = "Off (the app doesn't animate anything either)."
  "Pas de carte graphique AMD ou NVIDIA détectée : sans objet." = "No AMD or NVIDIA graphics card detected: not applicable."
  "Carte graphique AMD non détectée : sans objet." = "No AMD graphics card detected: not applicable."
  "Seule une puce graphique intégrée est détectée : sans objet." = "Only integrated graphics detected: not applicable."
  "Activé : la carte voit toute sa mémoire ({0} Go)." = "On: the card sees all of its memory ({0} GB)."
  "Probablement désactivé : active Above 4G Decoding et Re-Size BAR dans le BIOS." = "Probably off: enable Above 4G Decoding and Re-Size BAR in the BIOS."
  "Impossible à vérifier sur ce PC (Adrenalin l'indique dans Système)." = "Can't be checked on this PC (Adrenalin shows it under System)."
  "Moins de latence souris : Adrenalin > Jeux > Graphismes > Radeon Anti-Lag." = "Lower mouse latency: Adrenalin > Gaming > Graphics > Radeon Anti-Lag."
  "Vérifications : carte graphique" = "Checks: graphics card"
  "journaux dans C:\ProgramData\Lukzyr" = "logs in C:\ProgramData\Lukzyr"; "Réglages enregistrés dans HKCU\Software\Lukzyr, journaux et sauvegardes dans C:\ProgramData\Lukzyr." = "Settings stored in HKCU\Software\Lukzyr, logs and backups in C:\ProgramData\Lukzyr."
  "Animations réduites" = "Reduced animations"; "Effets plus courts et plus discrets, sans glissement ni pulsation." = "Shorter, subtler effects, no sliding or pulsing."
  "Coupées par Windows (Accessibilité > Effets visuels > Effets d'animation)." = "Turned off by Windows (Accessibility > Visual effects > Animation effects)."
  "Mode Jeu" = "Game Mode"; "Windows donne la priorité au jeu, enregistrement en arrière-plan coupé." = "Windows prioritises the game, background recording off."
  "Planification GPU accélérée" = "Hardware-accelerated GPU scheduling"; "Moins de latence en jeu (après redémarrage)." = "Less latency in games (after restart)."
  "Priorité aux jeux" = "Game priority"; "Plus de temps CPU et GPU pour les jeux." = "More CPU and GPU time for games."
  "Souris sans accélération" = "No mouse acceleration"; "Visée plus précise." = "More precise aim."
  "Désactiver VBS / intégrité de la mémoire" = "Disable VBS / memory integrity"; "+5 à 10 % de FPS, un peu moins de sécurité." = "+5 to 10% FPS, slightly less security."
  "TRIM des SSD" = "SSD TRIM"; "Garde les SSD rapides." = "Keeps SSDs fast."
  "Nettoyage des fichiers temporaires" = "Temporary files cleanup"; "Vide les dossiers Temp de Windows et de l'utilisateur." = "Empties the Windows and user Temp folders."
  "Nettoyage des caches shaders et miniatures" = "Shader and thumbnail cache cleanup"
  "Nettoyer" = "Clean up"
  "Désactiver l'hibernation" = "Disable hibernation"; "Libère plusieurs Go sur C: et coupe le démarrage rapide." = "Frees several GB on C: and turns off fast startup."
  "Assistant de stockage" = "Storage Sense"; "Nettoyage automatique des fichiers inutiles." = "Automatic cleanup of unneeded files."
  "Désactiver la transparence" = "Disable transparency"; "Effets visuels plus légers." = "Lighter visual effects."
  "Désactiver l'Optimisation de la distribution" = "Disable Delivery Optimization"; "Windows ne partage plus tes mises à jour avec d'autres PC (moins de bande passante utilisée)." = "Windows stops sharing your updates with other PCs (less bandwidth used)."
  "Réparation DISM + SFC" = "DISM + SFC repair"; "Vérifie et répare les fichiers Windows (environ 15 min)." = "Checks and repairs Windows files (about 15 min)."
  # Démarrage
  "Aucune appli au démarrage trouvée." = "No startup app found."; "Logiciel de sécurité : non modifiable" = "Security software: cannot be changed"
  "TÂCHES PLANIFIÉES AU DÉMARRAGE (INFORMATION)" = "SCHEDULED TASKS AT STARTUP (INFORMATION)"; "Aucune tâche planifiée tierce au démarrage." = "No third-party scheduled task at startup."
  "Éditeur inconnu" = "Unknown publisher"; "Impact estimé" = "Estimated impact"; "élevé" = "high"; "moyen" = "medium"; "faible" = "low"
  "Utilisateur" = "Current user"; "Tous les utilisateurs" = "All users"; "Tous les utilisateurs (32 bits)" = "All users (32-bit)"; "Dossier Démarrage" = "Startup folder"; "Dossier Démarrage (tous)" = "Startup folder (all users)"
  # Réseau
  "Automatique (FAI)" = "Automatic (ISP)"; "Aucune carte réseau physique connectée." = "No connected physical network adapter."
  "DNS ACTUEL" = "CURRENT DNS"; "Serveurs" = "Servers"; "Appliquer ce DNS" = "Apply this DNS"; "Vider le cache DNS" = "Flush DNS cache"; "Cache DNS vidé." = "DNS cache flushed."
  "manuel" = "manual"; "automatique" = "automatic"
  "Les serveurs DNS donnés par ta box / ton fournisseur d'accès (réglage d'origine de Windows)." = "The DNS servers given by your router / ISP (Windows default)."
  "Les DNS d'origine sont sauvegardés : « Tout annuler » (Outils) les remet. IPv4 et IPv6, cartes réseau physiques connectées." = "Your original DNS is saved: `"Undo everything`" (Tools) puts it back. IPv4 and IPv6, connected physical adapters."
  # Santé
  "Actualiser" = "Refresh"; "DISQUES" = "DISKS"; "usure" = "wear"; "erreurs de lecture" = "read errors"; "compteurs SMART non disponibles" = "SMART counters not available"
  "En bonne santé" = "Healthy"; "Problème" = "Problem"; "Usure élevée" = "High wear"; "Chaud" = "Hot"; "ESPACE LIBRE" = "FREE SPACE"; "libre" = "free"; "Go libres sur" = "GB free of"
  "PROCESSEUR ET MÉMOIRE" = "PROCESSOR AND MEMORY"; "Température processeur" = "CPU temperature"; "Capteur ACPI de la carte mère (indicatif)." = "Motherboard ACPI sensor (approximate)."
  "Ce PC ne communique pas sa température à Windows." = "This PC does not report its temperature to Windows."; "non disponible" = "not available"
  "Mémoire vive" = "Memory (RAM)"; "utilisés" = "used"; "point(s) à surveiller (en orange / rouge)." = "item(s) to watch (orange / red)."; "Tout va bien." = "All good."
  # Outils
  "Guide BIOS personnalisé" = "Personalised BIOS guide"; "Restaurer le système" = "System Restore"; "Applis au démarrage" = "Startup apps"
  "Gestionnaire de périphériques" = "Device Manager"; "Nettoyage de disque" = "Disk Cleanup"; "Redémarrer le PC" = "Restart the PC"; "Redémarrer maintenant ?" = "Restart now?"
  "Tout annuler" = "Undo everything"; "Remet les réglages d'origine (registre, services, alimentation, DNS, démarrage)." = "Restores the original settings (registry, services, power, DNS, startup)."
  "Non annulables : applis supprimées (débloat, Copilot, OneDrive) ou installées, Edge désinstallé, fichiers temporaires ou caches shaders / miniatures effacés, réparation DISM/SFC. Pour ça : « Restaurer le système » (point de restauration)." = "Cannot be undone: removed apps (debloat, Copilot, OneDrive) or installed apps, uninstalled Edge, deleted temp files or shader / thumbnail caches, DISM/SFC repair. For those: `"System Restore`" (restore point)."
  "Animations" = "Animations"; "Transitions et effets de l'interface. Désactive-les sur un PC lent." = "Interface transitions and effects. Turn them off on a slow PC."
  "Thème clair" = "Light theme"; "Interface claire au lieu de sombre (l'accent violet reste)." = "Light interface instead of dark (the purple accent stays)."
  "Langue" = "Language"; "Français ou English (l'interface redémarre)." = "Français or English (the interface restarts)."
  "Mise à jour de l'appli" = "App update"; "Vérification au démarrage..." = "Checking at startup..."; "Vérifier" = "Check"
  "Aucun serveur de mise à jour configuré." = "No update server configured."; "Vérification en cours..." = "Checking..."
  "Tu as la dernière version" = "You have the latest version"; "Nouvelle version disponible" = "New version available"; "Téléchargement en cours..." = "Downloading..."
  "Téléchargée sur le Bureau" = "Downloaded to the Desktop"; "Pas de connexion au serveur de mise à jour (l'appli marche normalement)." = "Can't reach the update server (the app works normally)."
  "Version" = "Version"; "disponible" = "available"; "Téléchargement..." = "Downloading..."; "Zip enregistré sur le Bureau" = "Zip saved to the Desktop"; "Télécharger" = "Download"; "Ouvrir" = "Open"
  # BIOS
  "Exporter le guide" = "Export the guide"; "Page support de ma carte mère" = "My motherboard's support page"; "Redémarrer dans le BIOS" = "Restart into the BIOS"
  "Redémarrage BIOS : UEFI requis" = "BIOS restart: UEFI required"; "Export impossible" = "Export failed"
  "Le PC va redémarrer MAINTENANT et ouvrir directement le BIOS (UEFI).`n`nEnregistre et ferme tes fichiers ouverts avant de continuer.`nDans le BIOS : F10 pour sauvegarder et quitter.`n`nRedémarrer dans le BIOS ?" = "The PC will restart NOW and open the BIOS (UEFI) directly.`n`nSave and close your open files before continuing.`nIn the BIOS: F10 to save and exit.`n`nRestart into the BIOS?"
  # Exécution et confirmations
  "APPLIQUER" = "APPLY"; "EN COURS" = "RUNNING"; "TERMINÉ" = "DONE"
  "Terminé. Redémarre le PC pour tout appliquer." = "Done. Restart the PC to apply everything."
  "Tout est fini ! Redémarrer maintenant ?" = "All done! Restart now?"; "Aucun réglage n'est activé." = "No setting is enabled."
  "LuKZyR Optimisation va faire :" = "LuKZyR Optimization will do:"
  "Un point de restauration est créé avant de commencer, et les réglages d'origine sont sauvegardés (Outils > Tout annuler)." = "A restore point is created first, and the original settings are saved (Tools > Undo everything)."
  "ATTENTION : Edge sera désinstallé. Garde un autre navigateur (Brave)." = "WARNING: Edge will be uninstalled. Keep another browser (Brave)."
  "ATTENTION : désactiver VBS réduit un peu la sécurité de Windows." = "WARNING: disabling VBS slightly reduces Windows security."
  "Continuer ?" = "Continue?"; "Attends la fin de l'opération en cours." = "Wait for the current operation to finish."
  "Une opération est en cours. Quitter quand même ?" = "An operation is running. Quit anyway?"
  "Suppression de Copilot" = "Copilot removal"; "Désinstallation de OneDrive" = "OneDrive uninstall"; "Mise à jour des autres applis" = "Update of other apps"; "Désinstallation de Microsoft Edge" = "Microsoft Edge uninstall"
  "Rien à annuler : aucun réglage n'a encore été modifié par LuKZyR Optimisation (ou tout a déjà été restauré)." = "Nothing to undo: LuKZyR Optimization hasn't changed any setting yet (or everything was already restored)."
  "Ces réglages vont retrouver leur valeur d'origine :" = "These settings will get their original value back:"
  "et {0} autre(s)" = "and {0} more"
  "Ne peuvent PAS être annulés : applis supprimées ou installées, Edge, fichiers temporaires ou caches shaders / miniatures effacés. Pour ça, utilise « Restaurer le système »." = "CANNOT be undone: removed or installed apps, Edge, deleted temp files or shader / thumbnail caches. For those, use `"System Restore`"."
  "Tout annuler maintenant ?" = "Undo everything now?"
  "Windows a refusé le redémarrage direct dans le BIOS ({0}).`nUtilise la touche indiquée dans le guide au démarrage." = "Windows refused to restart directly into the BIOS ({0}).`nUse the key shown in the guide at boot."
  "PC portable · " = "Laptop · "
  # v5.0 : nouvelle interface (onglets, Tableau de bord, badges)
  'Tableau de bord' = 'Dashboard'
  'Performance' = 'Performance'
  'Matériel' = 'Hardware'
  'Paramètres' = 'Settings'
  'Mon PC' = 'My PC'
  'Réparation et sécurité' = 'Repair & safety'
  'Nettoyage et confidentialité' = 'Cleanup & privacy'
  'Composants détectés sur ce PC.' = 'Components detected on this PC.'
  'Windows plus léger, moins de pubs et de suivi. Store, Xbox, Defender et Windows Update restent intacts.' = 'A lighter Windows with fewer ads and less tracking. Store, Xbox, Defender and Windows Update stay intact.'
  'WINDOWS PLUS LÉGER' = 'LIGHTER WINDOWS'
  'CONFIDENTIALITÉ' = 'PRIVACY'
  'FICHIERS' = 'FILES'
  'JEU' = 'GAMING'
  'PROCESSEUR ET ALIMENTATION' = 'CPU & POWER'
  'MÉMOIRE ET SÉCURITÉ' = 'MEMORY & SECURITY'
  'AFFICHAGE' = 'DISPLAY'
  'RÉPARATION' = 'REPAIR'
  'SÉCURITÉ' = 'SAFETY'
  'GRAPHIQUES ET AFFICHAGE' = 'GRAPHICS & DISPLAY'
  'ALIMENTATION ET VEILLE' = 'POWER & SLEEP'
  'FICHIERS ET CACHES' = 'FILES & CACHES'
  'ENTRETIEN WINDOWS' = 'WINDOWS MAINTENANCE'
  'APPLICATIONS PRÉINSTALLÉES' = 'PREINSTALLED APPS'
  'ANTIVIRUS ET VPN TIERS' = 'THIRD-PARTY ANTIVIRUS & VPN'
  'MISES À JOUR ET BANDE PASSANTE' = 'UPDATES & BANDWIDTH'
  'SÉCURITÉ WINDOWS' = 'WINDOWS SECURITY'
  'RESTAURATION' = 'RESTORE'
  'RACCOURCIS WINDOWS' = 'WINDOWS SHORTCUTS'
  'COMMUNICATION ET MUSIQUE' = 'COMMUNICATION & MUSIC'
  'NAVIGATEURS' = 'BROWSERS'
  'CRÉATION ET UTILITAIRES' = 'CREATION & UTILITIES'
  'ENTRETIEN' = 'MAINTENANCE'
  'Applis préinstallées inutiles (réinstallables depuis le Store), pubs, Bing, widgets.' = 'Useless preinstalled apps (reinstallable from the Store), ads, Bing, widgets.'
  'Réduire la télémétrie' = 'Reduce telemetry'
  'Données de diagnostic au minimum, service DiagTrack arrêté.' = 'Diagnostic data set to minimum, DiagTrack service stopped.'
  'Réduction de la télémétrie' = 'Telemetry reduction'
  'Installées depuis leurs sources officielles (winget). Décochées = rien ne se passe.' = 'Installed from their official sources (winget). Unchecked = nothing happens.'
  'Une appli installée ne s''enlève pas avec « Tout annuler » : désinstalle-la depuis Paramètres Windows > Applications.' = 'An installed app is not removed by `"Undo everything`": uninstall it from Windows Settings > Apps.'
  'Jeu, processeur, mémoire et affichage. Tout est annulable avec « Tout annuler ».' = 'Gaming, CPU, memory and display. Everything can be reverted with `"Undo everything`".'
  'Plus de temps CPU et GPU pour le jeu au premier plan.' = 'More CPU and GPU time for the game in the foreground.'
  'Visée plus précise, mouvement 1:1.' = 'More precise aim, 1:1 movement.'
  '+5 à 10 % de FPS, mais un peu moins de sécurité.' = '+5 to 10% FPS, but slightly less security.'
  'Windows ne partage plus tes mises à jour avec d''autres PC (moins de bande passante).' = 'Windows stops sharing your updates with other PCs (less bandwidth).'
  'Vide les dossiers Temp de Windows et de l''utilisateur (fichiers effacés).' = 'Empties the Windows and user Temp folders (files are deleted).'
  'Nettoyage de disque Windows' = 'Windows Disk Cleanup'
  'Ouvre l''outil Windows pour vider la corbeille, les anciennes mises à jour, etc.' = 'Opens the Windows tool to empty the recycle bin, old updates, etc.'
  # v5.16
  'Vide les caches de shaders (DirectX, NVIDIA, AMD, Intel) et les miniatures / icônes de l''Explorateur. Les premiers lancements de jeu peuvent recompiler les shaders (un court gel). Cache uniquement : sans risque, mais non annulable.' = 'Clears shader caches (DirectX, NVIDIA, AMD, Intel) and Explorer thumbnail / icon caches. The first game launches may recompile shaders (a short stutter). Cache only: safe, but cannot be undone.'
  'Vide les caches de shaders et les miniatures de l''Explorateur. Les premiers lancements de jeu peuvent recompiler les shaders (un court gel).' = 'Clears shader caches and Explorer thumbnails. The first game launches may recompile shaders (a short stutter).'
  'Vide les caches de shaders (DirectX, NVIDIA, AMD, Intel) et les caches d''icônes / miniatures de l''Explorateur.' = 'Clears shader caches (DirectX, NVIDIA, AMD, Intel) and Explorer icon / thumbnail caches.'
  'Les premiers lancements de jeu peuvent recompiler les shaders (un court gel).' = 'The first game launches may recompile shaders (a short stutter).'
  'Cache uniquement : sans risque pour Windows, mais « Tout annuler » ne peut pas le défaire.' = 'Cache only: safe for Windows, but `"Undo everything`" cannot undo it.'
  'Les fichiers en cours d''utilisation sont laissés en place.' = 'Files in use are left in place.'
  'Stockage, réparation, sécurité et raccourcis Windows.' = 'Storage, repair, safety and Windows shortcuts.'
  'Revenir à un point de restauration (créé avant chaque application).' = 'Go back to a restore point (created before every apply).'
  'Voir les composants et leurs pilotes.' = 'See components and their drivers.'
  'Nécessaire après certaines optimisations.' = 'Needed after some optimizations.'
  'Apparence, langue et mises à jour de LuKZyR Optimisation.' = 'Appearance, language and updates of LuKZyR Optimisation.'
  'À propos' = 'About'
  'réglages enregistrés dans HKCU\Software\Lukzyr, journaux dans C:\ProgramData\Lukzyr.' = 'settings stored in HKCU\Software\Lukzyr, logs in C:\ProgramData\Lukzyr.'
  'Ouvrir les journaux' = 'Open logs'
  'Optimiser en 1 clic' = 'Optimize in 1 click'
  'Choisis un profil : LuKZyR crée un point de restauration, sauvegarde tes réglages puis applique tout.' = 'Pick a profile: LuKZyR creates a restore point, backs up your settings, then applies everything.'
  'OPTIMISER' = 'OPTIMIZE'
  '≈ 5 min · annulable' = '≈ 5 min · reversible'
  'Redémarre le PC' = 'Restart the PC'
  'Étape {0}/{1}' = 'Step {0}/{1}'
  '{0} appli(s) lourde(s) au démarrage' = '{0} heavy app(s) at startup'
  'Démarrage léger : rien de lourd' = 'Light startup: nothing heavy'
  'Voir' = 'View'
  'Optimisé le {0} · annulable' = 'Optimized on {0} · reversible'
  'Dernière optimisation le {0}' = 'Last optimization on {0}'
  'Pas encore optimisé : choisis un profil' = 'Not optimized yet: pick a profile'
  'Version {0} disponible' = 'Version {0} available'
  'Disque à surveiller : {0}' = 'Disk to watch: {0}'
  '{0}: presque plein ({1} % libre)' = '{0}: almost full ({1}% free)'
  '{0}: {1} % libre seulement' = '{0}: only {1}% free'
  'Disques en bonne santé' = 'Disks are healthy'
  'Démarrage, réseau, réparation' = 'Startup, network, repair'
  'Pilotes, santé, BIOS' = 'Drivers, health, BIOS'
  'Thème, langue, mises à jour' = 'Theme, language, updates'
  'Avant chaque changement : point de restauration + sauvegarde des réglages. « Tout annuler » à tout moment.' = 'Before every change: restore point + settings backup. `"Undo everything`" at any time.'
  'SÛR' = 'SAFE'
  'AVANCÉ' = 'ADVANCED'
  'DÉFINITIF' = 'PERMANENT'
  'Option DÉFINITIVE : « {0} » ne pourra pas être annulé par « Tout annuler ».' = 'PERMANENT option: `"{0}`" cannot be reverted by `"Undo everything`".'
  'Option AVANCÉE : « {0} ». Lis bien sa description avant de l''activer.' = 'ADVANCED option: `"{0}`". Read its description carefully before enabling it.'
  'L''activer quand même ?' = 'Enable it anyway?'
  'Options avancées ou définitives :' = 'Advanced or permanent options:'
  'Un point de restauration est créé avant de commencer, et les réglages d''origine sont sauvegardés (bouton « Tout annuler »).' = 'A restore point is created first, and the original settings are backed up (`"Undo everything`" button).'
  'Profil' = 'Profile'
  'Installation' = 'Install'
  'Les DNS d''origine sont sauvegardés : « Tout annuler » (Système) les remet. IPv4 et IPv6, cartes réseau physiques connectées.' = 'The original DNS servers are backed up: `"Undo everything`" (System) restores them. IPv4 and IPv6, connected physical network adapters.'
  'Point de restauration' = 'Restore point'
  'Sauvegarde des réglages d''origine' = 'Backup of original settings'
  'Nettoyage de Windows' = 'Windows cleanup'
  'Installation des applications' = 'App installation'
  'Désinstallation d''Edge' = 'Edge uninstall'
  'Optimisation de Windows' = 'Windows optimization'
  'Restauration des réglages d''origine' = 'Restoring original settings'
  # v5.2 (écran de chargement, icônes)
  "Fermer" = "Close"
  "Réduire" = "Minimize"
  "Thème clair / sombre" = "Light / dark theme"
  "Détection incomplète (l'appli reste utilisable)" = "Detection incomplete (the app still works)"
  "Détection du processeur..." = "Detecting the processor..."
  "Carte graphique..." = "Graphics card..."
  "Carte mère..." = "Motherboard..."
  "Mémoire..." = "Memory..."
  "Disques..." = "Drives..."
  "Carte mère et BIOS..." = "Motherboard and BIOS..."
  "Préparation de l'interface..." = "Preparing the interface..."
  "Tableau de bord..." = "Dashboard..."
  "Finitions..." = "Finishing..."
  "Prêt" = "Ready"
  "batterie" = "battery"
  # v5.1
  "Lecture des cartes réseau..." = "Reading network adapters..."
  "Analyse des disques et de la mémoire..." = "Checking disks and memory..."
  "Aucun réglage trouvé." = "No setting found."
  "Démarrage : {0} appli(s) trouvée(s)." = "Startup: {0} app(s) found."
  "Enregistré" = "Saved"
  "Erreur d'affichage" = "Display error"
  "Exporter le journal" = "Export log"
  "Fichier texte" = "Text file"
  "Impossible d'enregistrer" = "Could not save"
  "Journal exporté" = "Log exported"
  "L'analyse n'a pas pu être faite (voir le Journal)." = "The check could not run (see the Log)."
  "L'étape « {0} » s'est terminée avec une erreur (code {1}). Les autres étapes continuent ; le détail est juste au-dessus. Bouton « Exporter le journal » pour le garder." = "Step `"{0}`" ended with an error (code {1}). The other steps go on; details are just above. Use `"Export log`" to keep them."
  "La liste des applis au démarrage n'a pas pu être lue (voir le Journal)." = "The startup app list could not be read (see the Log)."
  "Lecture des applis lancées avec Windows..." = "Reading the apps that start with Windows..."
  "Lecture des disques..." = "Reading disks..."
  "Lecture du démarrage..." = "Reading startup apps..."
  "Lecture en arrière-plan impossible" = "Background read failed"
  "Optimisation terminée" = "Optimization complete"
  "Ouvrir le dossier des journaux" = "Open the logs folder"
  "Page" = "Page"
  "Plus tard" = "Later"
  "Recherche : aller à" = "Search: go to"
  "Rechercher un réglage (Ctrl+F)" = "Search a setting (Ctrl+F)"
  "Rechercher" = "Search"
  "Effacer la recherche" = "Clear search"
  "Résultats" = "Results"
  "{0} résultat" = "{0} result"
  "{0} résultats" = "{0} results"
  "{0} sur {1} résultats" = "{0} of {1} results"
  "↑ ↓ Naviguer    Entrée Ouvrir    Échap Fermer" = "↑ ↓ Browse    Enter Open    Esc Close"
  "Redémarre le PC pour que tout soit pris en compte." = "Restart the PC so everything takes effect."
  "Redémarrer maintenant" = "Restart now"
  "Réglages d'origine remis" = "Original settings restored"
  "Terminé, avec des erreurs" = "Done, with errors"
  "Voir le journal" = "View log"
  "Opération terminée" = "Operation complete"
  "EFFETS VISUELS DE WINDOWS" = "WINDOWS VISUAL EFFECTS"
  "Réduire les animations des fenêtres" = "Reduce window animations"
  "Retire l’animation de réduction et d’agrandissement pour ce compte. Prend effet à la prochaine connexion." = "Turns off minimize and maximize animations for this account. Takes effect at the next sign-in."
  "Réduire les animations de la barre des tâches" = "Reduce taskbar animations"
  "Retire les animations des icônes de la barre des tâches pour ce compte. Prend effet à la prochaine connexion." = "Turns off taskbar icon animations for this account. Takes effect at the next sign-in."
  "Étapes en échec" = "Failed steps"
  "Réglages restaurés" = "Restored settings"
  "Éléments traités" = "Items processed"
  "{0} étape en échec" = "{0} failed step"
  "{0} étapes en échec" = "{0} failed steps"
  "{0} élément traité" = "{0} item processed"
  "{0} éléments traités" = "{0} items processed"
  "Point de restauration récent réutilisé." = "A recent restore point was reused."
  "Point de restauration créé." = "Restore point created."
  "Exécution sans point de restauration." = "Ran without a restore point."
  "Certains réglages prennent effet au redémarrage." = "Some settings take effect after a restart."
  "Enregistre ton travail avant de redémarrer le PC. Redémarrer maintenant ?" = "Save your work before restarting the PC. Restart now?"
  "Le PC n'a pas pu redémarrer. Consulte le Journal." = "The PC could not restart. See the Log."
  "En un coup d’œil" = "At a glance"
  "Dans ce rapport" = "In this report"
  "Aucune donnée disponible." = "No data available."
  "Barrette {0}" = "Module {0}"
  "{0} réglage(s) appliqué(s) en {1} min · point de restauration créé." = "{0} setting(s) applied in {1} min · restore point created."
  "{0} valeur(s) d'origine remise(s) en {1} min." = "{0} original value(s) restored in {1} min."
  "{0} étape(s) avec une erreur : {1}. Détails dans le Journal." = "{0} step(s) with an error: {1}. Details in the Log."
  "SÛR : réversible avec « Tout annuler »." = "SAFE: reversible with `"Undo everything`"."
  "AVANCÉ : réversible, mais change un comportement important de Windows. Lis bien la description." = "ADVANCED: reversible, but changes an important Windows behaviour. Read the description carefully."
  "DÉFINITIF : ne peut pas être annulé par « Tout annuler » (seulement par un point de restauration)." = "PERMANENT: cannot be undone with `"Undo everything`" (only with a restore point)."
  # v5.3 (v0.1 bêta)
  "bêta" = "beta"
  "Version bêta : merci de signaler les bugs (Journal > Exporter le journal)." = "Beta version: please report bugs (Log > Export log)."
  "Ouverture du dossier" = "Opening folder"
  "Dossier ouvert" = "Folder opened"
  "Impossible d'ouvrir le dossier" = "Could not open the folder"
  "L'Explorateur Windows n'a pas ouvert le dossier. Son chemin a été copié : colle-le dans la barre d'adresse de l'Explorateur." = "Windows Explorer did not open the folder. Its path has been copied: paste it into the Explorer address bar."
  "Source" = "Source"
  "Température carte graphique" = "Graphics card temperature"
  "Ce PC ne donne pas sa température à Windows : LibreHardwareMonitor peut la lire." = "This PC doesn't report its temperature to Windows: LibreHardwareMonitor can read it."
  "Les Ryzen ne donnent pas leur température à Windows : LibreHardwareMonitor peut la lire." = "AMD Ryzen CPUs don't report their temperature to Windows: LibreHardwareMonitor can read it."
  "LibreHardwareMonitor ouvert : active Options > Remote Web Server > Run, puis Actualiser." = "LibreHardwareMonitor is open: enable Options > Remote Web Server > Run, then Refresh."
  "Installer LibreHardwareMonitor" = "Install LibreHardwareMonitor"
  "LibreHardwareMonitor est un outil gratuit et open source qui lit les capteurs (températures, ventilateurs). Il sera installé depuis le dépôt officiel winget." = "LibreHardwareMonitor is a free, open-source tool that reads sensors (temperatures, fans). It will be installed from the official winget repository."
  "Bon à savoir : il utilise son propre pilote de lecture des capteurs, que certains antivirus (dont Microsoft Defender) peuvent signaler. LuKZyR ne l'installe pas lui-même et ne touche pas à l'antivirus." = "Good to know: it uses its own sensor driver, which some antivirus software (including Microsoft Defender) may flag. LuKZyR does not install it itself and does not touch the antivirus."
  "Ensuite : ouvre LibreHardwareMonitor, active Options > Remote Web Server > Run, puis Actualiser dans Santé." = "Then: open LibreHardwareMonitor, enable Options > Remote Web Server > Run, then Refresh in Health."
  "Installer maintenant ?" = "Install now?"
  "winget (App Installer) est introuvable sur ce PC. Installe-le depuis le Microsoft Store, ou télécharge LibreHardwareMonitor sur son site officiel." = "winget (App Installer) was not found on this PC. Install it from the Microsoft Store, or download LibreHardwareMonitor from its official website."
  "{0} élément(s) installé(s) en {1} min." = "{0} item(s) installed in {1} min."
  "{0} élément(s) traité(s) en {1} min." = "{0} item(s) processed in {1} min."
  "1 module détecté" = "1 module detected"
  "{0} Go sur un seul module détecté." = "{0} GB on a single detected module."
  "{0} Go sur un seul module (machine virtuelle) : normal, rien à ajouter." = "{0} GB on a single module (virtual machine): normal, nothing to add."
  "Mémoire soudée (souvent LPDDR) : on ne peut généralement pas ajouter de barrette." = "Soldered memory (often LPDDR): you usually cannot add a stick."
  "Carte d'affichage de base" = "Basic display adapter"
  "BIOS, LAN, audio : page support officielle du fabricant." = "BIOS, LAN, audio: official manufacturer support page."
  "Carte mère / PC " = "Motherboard / PC "
  "Windows (zone thermique)" = "Windows (thermal zone)"
  # v5.6 (correctifs du compte rendu de bugs)
  "NON RÉVERSIBLE" = "NOT REVERSIBLE"
  "NON RÉVERSIBLE : sans risque pour Windows, mais « Tout annuler » ne peut pas le défaire (applis supprimées ou installées, fichiers effacés)." = "NOT REVERSIBLE: safe for Windows, but `"Undo everything`" cannot undo it (removed or installed apps, deleted files)."
  "Applis inutiles retirées pour tous les comptes du PC (réinstallables via le Store), pubs, Bing, widgets." = "Useless apps removed for all accounts on this PC (reinstallable from the Store), ads, Bing, widgets."
  "Retire l'appli Copilot (réinstallable via le Store) et masque son bouton." = "Removes the Copilot app (reinstallable from the Store) and hides its button."
  "Gain variable (souvent faible), un peu moins de sécurité. Peut rester actif avec Hyper-V ou WSL2." = "Variable gain (often small), slightly less security. May stay on with Hyper-V or WSL2."
  "Installation des applis" = "App installation"; "Installation des pilotes" = "Driver installation"
  "Non annulable avec « Tout annuler » :" = "Cannot be undone with `"Undo everything`":"
  "APPLIQUER prend en compte les cases cochées de TOUTES les pages." = "APPLY uses the ticked options of ALL pages."
  "Sur cette page (« {0} ») : {1} élément(s)." = "On this page (`"{0}`"): {1} item(s)."
  "Sur d'autres pages ({0}) : {1} élément(s)." = "On other pages ({0}): {1} item(s)."
  "Oui = tout appliquer" = "Yes = apply everything"; "Non = seulement cette page" = "No = this page only"; "Annuler = ne rien faire" = "Cancel = do nothing"
  "Le point de restauration n'a pas pu être créé (détail dans le Journal)." = "The restore point could not be created (details in the Log)."
  "Continuer quand même, SANS point de restauration ?" = "Continue anyway, WITHOUT a restore point?"
  "Non = tout arrêter : rien n'a encore été modifié." = "No = stop everything: nothing has been changed yet."
  "Arrêté : rien n'a été modifié." = "Stopped: nothing was changed."; "Arrêté : rien n'a été modifié" = "Stopped: nothing was changed"
  "Exécution arrêtée" = "Execution stopped"
  "Impossible de rétablir la fréquence des points de restauration. Consulte le Journal." = "The restore point frequency could not be reset. See the Log."
  "Le point de restauration n'a pas pu être créé : tu as choisi de tout arrêter." = "The restore point could not be created: you chose to stop everything."
  "{0} réglage(s) appliqué(s) en {1} min · SANS point de restauration." = "{0} setting(s) applied in {1} min · WITHOUT a restore point."
  "L'étape en cours sera arrêtée (avec tout ce qu'elle a lancé) et peut rester à moitié faite." = "The current step will be stopped (with everything it started) and may be left half done."
  "Appliqué tout de suite, comme le Gestionnaire des tâches. Annulable avec « Tout annuler »." = "Applied right away, like Task Manager. Can be undone with `"Undo everything`"."
  "≈ 5 min" = "≈ 5 min"
}
# Traductions sensibles à la casse (la table ci-dessus ignore la casse : « SYSTÈME » = « Système »)
$ENexact = New-Object Collections.Hashtable ([StringComparer]::Ordinal)
$ENexact["Système"] = "System"
$ENexact["BÊTA"] = "BETA"

# v5.7 : nouveautés (session de jeu, espace disque, rapport système, pilote graphique, moniteur, mise à jour)
$EN['Réglages'] = 'Settings'
$EN['Session de jeu'] = 'Game session'
$EN['Espace disque'] = 'Disk space'
$EN['IMPACT ÉLEVÉ'] = 'HIGH IMPACT'
$EN['IMPACT MOYEN'] = 'MEDIUM IMPACT'
$EN['IMPACT FAIBLE'] = 'LOW IMPACT'
$EN['Impact estimé ÉLEVÉ : appli connue pour ralentir l''ouverture de session (launcher, synchro, logiciel RGB...). La désactiver ne la désinstalle pas.'] = 'Estimated HIGH impact: an app known to slow down sign-in (launcher, sync, RGB software...). Disabling it does not uninstall it.'
$EN['Impact estimé MOYEN : programme assez lourd lancé avec Windows.'] = 'Estimated MEDIUM impact: a fairly heavy program started with Windows.'
$EN['Impact estimé FAIBLE : petit programme, peu de différence au démarrage.'] = 'Estimated LOW impact: a small program, little difference at startup.'
$EN['RAPPORT'] = 'REPORT'
$EN['Rapport système'] = 'System report'
$EN['Exporter'] = 'Export'
$EN['Matériel, pilotes, Windows et réglages appliqués dans un fichier HTML + texte sur le Bureau. Rien n''est envoyé.'] = 'Hardware, drivers, Windows and applied settings in an HTML + text file on the Desktop. Nothing is sent.'
$EN['Pilote graphique installé'] = 'Installed graphics driver'
$EN['du {0}'] = 'from {0}'
$EN['il y a {0} jours'] = '{0} days ago'
$EN['Pilote de plus de 6 mois : une version plus récente existe sûrement. Vérifie sur le site officiel.'] = 'Driver older than 6 months: a newer version most likely exists. Check the official website.'
$EN['Pilote récent : rien à faire.'] = 'Recent driver: nothing to do.'
$EN['Date du pilote inconnue.'] = 'Driver date unknown.'
$EN['Site officiel'] = 'Official website'
$EN['PAGES OFFICIELLES DES FABRICANTS'] = 'OFFICIAL MANUFACTURER PAGES'
$EN['Date du rapport'] = 'Report date'
$EN['Nom du PC'] = 'PC name'
$EN['Modèle'] = 'Model'
$EN['Cœurs / threads'] = 'Cores / threads'
$EN['Fréquence de base'] = 'Base clock'
$EN['pilote'] = 'driver'
$EN['Carte mère et BIOS'] = 'Motherboard and BIOS'
$EN['Total'] = 'Total'
$EN['état'] = 'health'
$EN['libres sur'] = 'free of'
$EN['Édition'] = 'Edition'
$EN['Démarré le'] = 'Started on'
$EN['Type'] = 'Type'
$EN['PC fixe'] = 'Desktop PC'
$EN['Écran et alimentation'] = 'Display and power'
$EN['Écran principal'] = 'Main display'
$EN['max'] = 'max'
$EN['Plan d''alimentation'] = 'Power plan'
$EN['non lue (ouvre LibreHardwareMonitor pour l''avoir)'] = 'not read (open LibreHardwareMonitor to get it)'
$EN['Températures'] = 'Temperatures'
$EN['Dernière optimisation'] = 'Last optimization'
$EN['jamais'] = 'never'
$EN['Réglages annulables'] = 'Settings that can be undone'
$EN['Réglages appliqués par LuKZyR'] = 'Settings applied by LuKZyR'
$EN['actif'] = 'enabled'
$EN['désactivé'] = 'disabled'
$EN['impact'] = 'impact'
$EN['Ouvre Système > Démarrage une fois pour l''ajouter au rapport.'] = 'Open System > Startup once to add it to the report.'
$EN['État'] = 'Status'
$EN['aucune'] = 'none'
$EN['Rapport en lecture seule : aucun mot de passe, aucune clé de licence, aucun fichier personnel.'] = 'Read-only report: no password, no license key, no personal file.'
$EN['Rapport système exporté'] = 'System report exported'
$EN['Rapport système impossible'] = 'System report failed'
$EN['OneDrive'] = 'OneDrive'
$EN['Synchro des fichiers (reprend où elle en était).'] = 'File sync (resumes where it left off).'
$EN['Microsoft Teams'] = 'Microsoft Teams'
$EN['Messagerie Microsoft.'] = 'Microsoft messaging.'
$EN['Widgets Windows'] = 'Windows Widgets'
$EN['Météo et actus (Windows le relance tout seul si besoin).'] = 'Weather and news (Windows restarts it by itself when needed).'
$EN['Lien avec le téléphone'] = 'Phone Link'
$EN['Synchro avec ton téléphone.'] = 'Sync with your phone.'
$EN['Mises à jour et synchro Adobe.'] = 'Adobe updates and sync.'
$EN['Laisse décoché si tu écoutes de la musique en jouant.'] = 'Leave unchecked if you listen to music while playing.'
$EN['Laisse décoché si tu es en vocal.'] = 'Leave unchecked if you are in voice chat.'
$EN['Ne coche pas si ton jeu passe par Epic.'] = 'Do not check if your game runs through Epic.'
$EN['Ne coche pas si ton jeu passe par EA.'] = 'Do not check if your game runs through EA.'
$EN['Ne coche pas si ton jeu passe par Ubisoft.'] = 'Do not check if your game runs through Ubisoft.'
$EN['Ne coche pas si ton jeu passe par Battle.net.'] = 'Do not check if your game runs through Battle.net.'
$EN['Logiciels RGB (iCUE, G HUB, Razer)'] = 'RGB software (iCUE, G HUB, Razer)'
$EN['Les lumières peuvent rester figées pendant la session.'] = 'Lighting may stay frozen during the session.'
$EN['Ferme les applis inutiles pendant que tu joues, puis les relance. Rien n''est désinstallé ni modifié dans Windows.'] = 'Closes unneeded apps while you play, then restarts them. Nothing is uninstalled or changed in Windows.'
$EN['Aucune session en cours'] = 'No session running'
$EN['Coche les applis à fermer, puis Démarrer. À la fin, tout est relancé.'] = 'Check the apps to close, then Start. At the end, everything is restarted.'
$EN['Démarrer la session'] = 'Start session'
$EN['Terminer la session'] = 'End session'
$EN['Plan Performances élevées pendant la session'] = 'High performance power plan during the session'
$EN['Désactivé sur PC portable (autonomie).'] = 'Disabled on laptops (battery life).'
$EN['Ton plan d''alimentation actuel est remis à la fin de la session.'] = 'Your current power plan is restored at the end of the session.'
$EN['APPLIS À FERMER (RELANCÉES À LA FIN)'] = 'APPS TO CLOSE (RESTARTED AT THE END)'
$EN['Jamais fermés : Windows, l''antivirus, les pilotes, ton jeu et tout ce qui n''est pas coché. Une appli fermée perd ce qui n''était pas enregistré : enregistre avant de démarrer.'] = 'Never closed: Windows, the antivirus, drivers, your game and anything not checked. A closed app loses anything unsaved: save before starting.'
$EN['Session de jeu en cours'] = 'Game session running'
$EN['depuis {0}'] = 'since {0}'
$EN['Fermées'] = 'Closed'
$EN['Aucune appli fermée.'] = 'No app closed.'
$EN['Plan Performances élevées actif.'] = 'High performance plan active.'
$EN['En cours : clique pour terminer.'] = 'Running: click to end it.'
$EN['Ferme les applis inutiles en jeu.'] = 'Closes unneeded apps while gaming.'
$EN['ouverte'] = 'open'
$EN['pas lancée'] = 'not running'
$EN['Aucune des applis cochées n''est ouverte et le plan d''alimentation est déjà le bon : rien à faire.'] = 'None of the checked apps is open and the power plan is already right: nothing to do.'
$EN['Session de jeu impossible'] = 'Game session failed'
$EN["Impossible d'activer le plan d'alimentation de la session."] = 'Could not activate the game session power plan.'
$EN['État de la session illisible.'] = 'The game session file could not be read.'
$EN["Impossible de rétablir le plan d'alimentation. La session est conservée pour réessayer."] = 'Could not restore the power plan. The session was kept so you can retry.'
$EN['Session de jeu démarrée'] = 'Game session started'
$EN['aucune appli fermée'] = 'no app closed'
$EN['plan Performances élevées'] = 'high performance plan'
$EN['Session de jeu terminée : {0} appli(s) relancée(s)'] = 'Game session ended: {0} app(s) restarted'
$EN['plan d''alimentation remis'] = 'power plan restored'
$EN['{0} applis au démarrage, {1} actives.'] = '{0} startup apps, {1} enabled.'
$EN['{0} à fort impact encore active(s) : désactive celles dont tu n''as pas besoin dès l''allumage.'] = '{0} high-impact app(s) still enabled: disable the ones you don''t need right at boot.'
$EN['Aucune appli à fort impact active : ton démarrage est propre.'] = 'No high-impact app enabled: your startup is clean.'
$EN['Téléchargements'] = 'Downloads'
$EN['Bureau'] = 'Desktop'
$EN['Documents'] = 'Documents'
$EN['Vidéos'] = 'Videos'
$EN['Images'] = 'Pictures'
$EN['Musique'] = 'Music'
$EN['Fichiers temporaires (utilisateur)'] = 'Temporary files (user)'
$EN['Fichiers temporaires (Windows)'] = 'Temporary files (Windows)'
$EN['Corbeille'] = 'Recycle Bin'
$EN['Mo'] = 'MB'
$EN['Ko'] = 'KB'
$EN['Mesure de l''espace utilisé (jusqu''à une minute sur un gros disque)...'] = 'Measuring used space (up to a minute on a large drive)...'
$EN['Mesurer à nouveau'] = 'Measure again'
$EN['Clique sur une ligne pour ouvrir le dossier. Pour faire de la place : Nettoyage > fichiers temporaires, ou désinstalle les jeux que tu n''utilises plus.'] = 'Click a row to open the folder. To free up space: Cleanup > temporary files, or uninstall games you no longer play.'
$EN['Mesure impossible (voir le Journal).'] = 'Measurement failed (see the Log).'
$EN['DOSSIERS PERSONNELS'] = 'PERSONAL FOLDERS'
$EN['JEUX STEAM (PLUS GROS)'] = 'STEAM GAMES (LARGEST)'
$EN['TEMPORAIRES ET CORBEILLE'] = 'TEMPORARY FILES AND RECYCLE BIN'
$EN['APPDATA (PLUS GROS DOSSIERS)'] = 'APPDATA (LARGEST FOLDERS)'
$EN['FICHIERS SYSTÈME (GÉRÉS PAR WINDOWS, NE PAS SUPPRIMER)'] = 'SYSTEM FILES (MANAGED BY WINDOWS, DO NOT DELETE)'
$EN['Mesure arrêtée avant la fin (dossier énorme ou protégé) : la taille réelle est plus grande.'] = 'Measurement stopped before the end (huge or protected folder): the real size is larger.'
$EN['Espace disque : {0} élément(s) mesuré(s).'] = 'Disk space: {0} item(s) measured.'
$EN['Ce qui prend de la place sur tes disques. Lecture seule : rien n''est supprimé ni déplacé.'] = 'What takes up space on your drives. Read-only: nothing is deleted or moved.'
$EN['Rendu lissé'] = 'Smooth rendering'
$EN['Cartes sans scintillement. Coupe-le seulement si l''affichage a un souci (prend effet au prochain lancement).'] = 'Flicker-free cards. Turn it off only if something displays wrong (takes effect on next launch).'
$EN['Mesures en direct, mises à jour toutes les 1,5 s quand le Tableau de bord est affiché.'] = 'Live readings, updated every 1.5 s while the Dashboard is shown.'
$EN['Espace utilisé sur le disque système'] = 'Used space on the system drive'
$EN['ACCÈS RAPIDE'] = 'QUICK ACCESS'
$EN['Matériel et réglages en HTML.'] = 'Hardware and settings as HTML.'
$EN['Ce qui prend de la place.'] = 'What takes up space.'
$EN['Une session de jeu est en cours : termine-la d''abord (Performance > Session de jeu), elle a fermé des applis et peut avoir changé le plan d''alimentation.'] = 'A game session is running: end it first (Performance > Game session), it closed apps and may have changed the power plan.'
$EN['Une session de jeu est en cours.'] = 'A game session is running.'
$EN['La terminer maintenant (relancer les applis fermées, remettre le plan d''alimentation) ?'] = 'End it now (restart the closed apps, restore the power plan)?'
$EN['Non = la garder : elle sera proposée au prochain lancement.'] = 'No = keep it: you will be asked again on next launch.'
$EN['Une session de jeu n''a pas été terminée'] = 'A game session was not ended'
$EN['démarrée le {0}'] = 'started on {0}'
$EN['Vérification impossible'] = 'Check failed'
$EN['L''appli marche normalement.'] = 'The app works normally.'
$EN['réponse trop grosse'] = 'response too large'
$EN['pas de connexion Internet (adresse introuvable)'] = 'no Internet connection (address not found)'
$EN['le serveur n''a pas répondu en 10 s'] = 'the server did not answer within 10 s'
$EN['serveur injoignable (pare-feu, proxy ou antivirus ?)'] = 'server unreachable (firewall, proxy or antivirus?)'
$EN['connexion sécurisée refusée (date et heure du PC, ou antivirus qui inspecte le HTTPS ?)'] = 'secure connection refused (PC date and time, or an antivirus inspecting HTTPS?)'
$EN['connexion sécurisée (TLS 1.2) impossible'] = 'secure connection (TLS 1.2) failed'
$EN['fichier introuvable sur GitHub (404)'] = 'file not found on GitHub (404)'
$EN['pas de connexion Internet ou serveur injoignable'] = 'no Internet connection or server unreachable'
$EN['connexion sécurisée (TLS) impossible : date et heure du PC, ou antivirus qui inspecte le HTTPS ?'] = 'secure connection (TLS) failed: PC date and time, or an antivirus inspecting HTTPS?'
$EN['lien de téléchargement refusé dans version.json (https et .zip obligatoires)'] = 'download link refused in version.json (https and .zip required)'
$EN['empreinte sha256 illisible dans version.json'] = 'unreadable sha256 hash in version.json'
$EN['aucune release avec un numéro de version'] = 'no release with a version number'
$EN['release sans fichier .zip'] = 'release without a .zip file'
$EN['releases GitHub'] = 'GitHub releases'
$EN['téléchargement'] = 'download'
$EN['numéro de version illisible dans version.json'] = 'unreadable version number in version.json'
$EN['GitHub limite les vérifications pour l''instant'] = 'GitHub is rate-limiting checks for now'
$EN['réessaie dans une heure'] = 'try again in an hour'
$EN['réponse du serveur : erreur'] = 'server response: error'
$EN['adresse refusée (https obligatoire)'] = 'address refused (https required)'

# v5.8 : interface « barre latérale » (navigation, tableau de bord, score d'optimisation)
$EN['Tout est annulable'] = 'Everything can be undone'
$EN['Sauvegarde des réglages'] = 'Settings backup'
$EN['Point de restauration + sauvegarde avant chaque changement.'] = 'Restore point + backup before every change.'
$EN['Remet les réglages modifiés par LuKZyR à leur valeur d''origine.'] = 'Puts the settings changed by LuKZyR back to their original value.'
$EN['Session en cours'] = 'Session running'
$EN['Ferme les applis en jeu'] = 'Closes apps while gaming'
$EN['Bonjour'] = 'Hello'
$EN['Bonsoir'] = 'Good evening'
$EN['Optimiser maintenant'] = 'Optimize now'
$EN['Point de restauration + sauvegarde de tes réglages, puis application du profil choisi.'] = 'Restore point + backup of your settings, then the chosen profile is applied.'
$EN['SCORE D''OPTIMISATION'] = 'OPTIMIZATION SCORE'
$EN['Point de restauration + sauvegarde de tes réglages avant d''appliquer le profil.'] = 'Restore point + backup of your settings before the profile is applied.'
$EN['PROFILS EN 1 CLIC'] = '1-CLICK PROFILES'
$EN['EN DIRECT'] = 'LIVE'
$EN['DISQUE'] = 'DRIVE'
$EN['Captures de jeu en arrière-plan coupées'] = 'Background game capture off'
$EN['Planification GPU à accélération matérielle'] = 'Hardware-accelerated GPU scheduling'
$EN['Télémétrie réduite'] = 'Reduced telemetry'
$EN['Applis lourdes au démarrage'] = 'Heavy startup apps'
$EN['Espace libre sur {0}'] = 'Free space on {0}'
$EN['Pilote graphique de moins de 6 mois'] = 'Graphics driver less than 6 months old'
$EN['{0} jours'] = '{0} days'
$EN['Ton PC est en '] = 'Your PC is in '
$EN['bonne forme'] = 'good shape'
$EN['Ton PC est '] = 'Your PC is '
$EN['presque optimisé'] = 'almost optimized'
$EN['Ton PC peut '] = 'Your PC can '
$EN['aller plus vite'] = 'go faster'
$EN['{0}/{1} réglages recommandés en place'] = '{0}/{1} recommended settings in place'
$EN['Détails'] = 'Details'
$EN['Score calculé seulement avec ce qui est lu sur ce PC. Clique sur « Détails » pour voir chaque point.'] = 'Score computed only from what is read on this PC. Click “Details” to see each point.'
$EN['Score d''optimisation : {0}/100'] = 'Optimization score: {0}/100'
$EN['Seul ce qui est lu sur ce PC compte. Une mesure pas encore lue n''est pas comptée. VBS n''est pas compté : c''est un compromis sécurité / performance.'] = 'Only what is read on this PC counts. A reading not done yet is not counted. VBS is not counted: it is a security / performance trade-off.'
$EN['Ce qui prend de la place'] = 'What takes up space'
$EN['Rechercher (Ctrl+F)'] = 'Search (Ctrl+F)'
# v5.12 : signaler un bug (Discord)
$EN['Signaler un bug'] = 'Report a bug'
$EN['Signaler un bug (Discord)'] = 'Report a bug (Discord)'
$EN['Un souci ? Explique-le sur le serveur Discord (joins le journal : Journal > Exporter).'] = 'A problem? Describe it on the Discord server (attach the log: Log > Export).'
$EN['Le navigateur ne s''est pas ouvert. Lien copié, colle-le dans ton navigateur :'] = 'The browser did not open. Link copied, paste it into your browser:'
# v5.13 : repli du sous-titre Accueil si aucune carte graphique n'est détectée
$EN['Carte graphique'] = 'Graphics card'
# v5.14 : Système > Réparer, Matériel > Diagnostic, nouveaux réglages, point de restauration réutilisé
$EN['Réparer'] = 'Repair'
$EN['Diagnostic'] = 'Diagnostics'
$EN['À faire'] = 'To do'
$EN['Installé'] = 'Installed'
$EN['Incomplet'] = 'Incomplete'
$EN['Absent'] = 'Missing'
$EN['Date : {0}.'] = 'Date: {0}.'
$EN['À corriger'] = 'To fix'
$EN['À jour'] = 'Up to date'
$EN['Mise à jour à installer'] = 'Update to install'
$EN['Windows 10'] = 'Windows 10'
$EN['Conseil : {0} im/s'] = 'Tip: {0} fps'
$EN['Rien à signaler.'] = 'Nothing to report.'
$EN['Bluetooth (manettes, casques, souris)'] = 'Bluetooth (controllers, headsets, mice)'
$EN['Rien à réparer'] = 'Nothing to repair'
$EN['À vérifier'] = 'Check'
$EN['Éditeur : {0}'] = 'Publisher: {0}'
$EN['lancée'] = 'runs'
$EN['inconnu'] = 'unknown'
$EN['Antivirus'] = 'Antivirus'
$EN['OK'] = 'OK'
$EN['Aucune vérification ne concerne ce PC.'] = 'No check applies to this PC.'
$EN['Ouvre Matériel > Diagnostic une fois pour l''ajouter au rapport.'] = 'Open Hardware > Diagnostics once to add it to the report.'
$EN['Aucun réglage nuisible trouvé.'] = 'No harmful setting found.'
$EN['Tâches planifiées d''autres éditeurs'] = 'Scheduled tasks from other publishers'
$EN['Ouvre Système > Réparer une fois pour l''ajouter au rapport.'] = 'Open System > Repair once to add it to the report.'
$EN['Réglages d''autres optimiseurs'] = 'Settings from other optimizers'
$EN['Effet faible : un peu moins de processeur réservé aux tâches de fond. Pas de gain d''images/s garanti.'] = 'Small effect: a little less CPU reserved for background tasks. No guaranteed FPS gain.'
$EN['Carte graphique puissante pour les jeux'] = 'Powerful graphics card for games'
$EN['PC à 2 cartes graphiques : tes jeux Steam et Epic utilisent la carte dédiée. Tes choix déjà faits sont gardés.'] = 'PC with 2 graphics cards: your Steam and Epic games use the dedicated card. Choices you already made are kept.'
$EN['Mode d''alimentation « Meilleures performances »'] = '"Best performance" power mode'
$EN['Windows 11, sur secteur : le processeur monte plus vite en fréquence. Gain faible. Va avec le plan Utilisation normale.'] = 'Windows 11, plugged in: the CPU ramps up its clock faster. Small gain. Goes with the Balanced plan.'
$EN['Libère plusieurs Go sur C: et coupe le démarrage rapide. Jamais sur un PC avec batterie.'] = 'Frees several GB on C: and turns off fast startup. Never on a PC with a battery.'
$EN['Optimiser les lecteurs'] = 'Optimize drives'
$EN['Réactive l''optimisation hebdomadaire de Windows si elle a été coupée, et retrim des SSD tout de suite.'] = 'Turns Windows'' weekly optimization back on if it was disabled, and retrims SSDs right away.'
$EN['PC avec batterie : l''hibernation reste active (elle protège ton travail quand la batterie est vide).'] = 'PC with a battery: hibernation stays on (it protects your work when the battery runs out).'
$EN['Windows 11 seulement : non disponible sur ce Windows.'] = 'Windows 11 only: not available on this Windows.'
$EN['TÂCHES PLANIFIÉES AU DÉMARRAGE (POUR LES DÉSACTIVER : SYSTÈME › RÉPARER)'] = 'SCHEDULED TASKS AT STARTUP (TO TURN THEM OFF: SYSTEM › REPAIR)'
$EN['Mémoire en dual channel'] = 'Dual-channel memory'
$EN['1 module détecté'] = '1 module detected'
$EN['{0} Go sur un seul module détecté.'] = '{0} GB on a single detected module.'
$EN['Sur un portable, une partie de la mémoire peut être soudée : vérifie la fiche technique avant d''ajouter une barrette.'] = 'On a laptop, part of the memory may be soldered: check the spec sheet before adding a stick.'
$EN['Single channel'] = 'Single channel'
$EN['Une seule barrette ({0} Go) : la mémoire n''utilise qu''un canal, débit divisé par deux.'] = 'A single stick ({0} GB): memory uses only one channel, half the bandwidth.'
$EN['Ajoute une 2e barrette identique (même taille, même vitesse) : gain net en jeu.'] = 'Add a 2nd identical stick (same size, same speed): a clear gain in games.'
$EN['Dual channel'] = 'Dual channel'
$EN['{0} barrettes sur les canaux {1} ({2} Go).'] = '{0} sticks on channels {1} ({2} GB).'
$EN['Même canal'] = 'Same channel'
$EN['{0} barrettes, toutes sur le canal {1} : la mémoire n''utilise qu''un canal.'] = '{0} sticks, all on channel {1}: memory uses only one channel.'
$EN['PC éteint : place-les dans les emplacements conseillés par le manuel de la carte mère (souvent A2 et B2, les 2e et 4e en partant du processeur).'] = 'With the PC off: put them in the slots recommended by the motherboard manual (often A2 and B2, the 2nd and 4th from the CPU).'
$EN['Dual channel probable'] = 'Probably dual channel'
$EN['{0} barrettes ({1} Go). Ce PC n''indique pas les canaux : très probablement en dual channel.'] = '{0} sticks ({1} GB). This PC does not report channels: very likely dual channel.'
$EN['Lien PCIe de la carte graphique'] = 'Graphics card PCIe link'
$EN['x{0} au lieu de x{1}'] = 'x{0} instead of x{1}'
$EN['{0} : lien en x{1}, alors que la carte et son emplacement acceptent x{2}.'] = '{0}: link at x{1}, while the card and its slot support x{2}.'
$EN['PC éteint et débranché : vérifie que la carte est bien enfoncée et verrouillée. Certains emplacements partagent leurs lignes avec un SSD M.2 : regarde le manuel de la carte mère.'] = 'With the PC off and unplugged: check the card is fully seated and latched. Some slots share lanes with an M.2 SSD: check the motherboard manual.'
$EN['Emplacement x{0}'] = 'x{0} slot'
$EN['{0} accepte x{1}, mais son emplacement est limité à x{2}.'] = '{0} supports x{1}, but its slot is limited to x{2}.'
$EN['Mets la carte dans le 1er emplacement PCIe x16, le plus proche du processeur.'] = 'Put the card in the 1st PCIe x16 slot, the one closest to the CPU.'
$EN['{0} : lien en x{1}, le maximum possible. La vitesse du lien baisse au repos : c''est normal.'] = '{0}: link at x{1}, the maximum possible. Link speed drops at idle: that is normal.'
$EN['Pilote chipset AMD'] = 'AMD chipset driver'
$EN['{0} périphérique(s) AMD sans pilote.'] = '{0} AMD device(s) without a driver.'
$EN['Installe le dernier paquet « AMD Chipset Drivers » pour ta carte mère (site AMD ; sur un portable, site du fabricant du PC).'] = 'Install the latest "AMD Chipset Drivers" package for your motherboard (AMD site; on a laptop, the PC maker''s site).'
$EN['Gestion d''énergie AMD présente (version {0}).'] = 'AMD power management present (version {0}).'
$EN['Pilote de plus de 18 mois : installe le dernier paquet AMD Chipset Drivers.'] = 'Driver older than 18 months: install the latest AMD Chipset Drivers package.'
$EN['Site AMD'] = 'AMD site'
$EN['Gestion d''énergie AMD présente.'] = 'AMD power management present.'
$EN['Pilotes AMD de base présents, mais pas la gestion d''énergie AMD (PPM Provisioning).'] = 'Basic AMD drivers present, but not AMD power management (PPM Provisioning).'
$EN['Windows utilise des pilotes génériques pour le chipset.'] = 'Windows is using generic chipset drivers.'
$EN['Ryzen X3D : jeux sur le cache 3D'] = 'Ryzen X3D: games on the 3D cache'
$EN['pilote AMD 3D V-Cache absent'] = 'AMD 3D V-Cache driver missing'
$EN['service AMD 3D V-Cache arrêté'] = 'AMD 3D V-Cache service stopped'
$EN['Mode Jeu désactivé'] = 'Game Mode off'
$EN['Xbox Game Bar désinstallée'] = 'Xbox Game Bar uninstalled'
$EN['Pilote V-Cache, Mode Jeu et Game Bar présents : les jeux vont sur les cœurs avec le cache 3D.'] = 'V-Cache driver, Game Mode and Game Bar present: games go to the cores with the 3D cache.'
$EN['Installe le dernier pilote chipset AMD, laisse le Mode Jeu activé et la Xbox Game Bar installée (même sans l''utiliser). BIOS : « CPPC Dynamic Preferred Cores » sur Driver ou Auto.'] = 'Install the latest AMD chipset driver, keep Game Mode on and the Xbox Game Bar installed (even if you do not use it). BIOS: "CPPC Dynamic Preferred Cores" on Driver or Auto.'
$EN['Windows et Ryzen'] = 'Windows and Ryzen'
$EN['Windows 11 {0} (build {1}) : optimisation Ryzen incluse.'] = 'Windows 11 {0} (build {1}): Ryzen optimization included.'
$EN['Windows 11 {0} (build {1}) avec la mise à jour d''août 2024 : optimisation Ryzen incluse.'] = 'Windows 11 {0} (build {1}) with the August 2024 update: Ryzen optimization included.'
$EN['Windows 11 {0} (build {1}) sans la mise à jour d''août 2024 (KB5041587) qui accélère les Ryzen.'] = 'Windows 11 {0} (build {1}) without the August 2024 update (KB5041587) that speeds up Ryzen.'
$EN['Paramètres > Windows Update : installe les mises à jour, ou passe à Windows 11 24H2.'] = 'Settings > Windows Update: install the updates, or move to Windows 11 24H2.'
$EN['Windows Update'] = 'Windows Update'
$EN['Trop ancien'] = 'Too old'
$EN['Windows 11 21H2 (build {0}) : plus mis à jour, sans l''optimisation Ryzen.'] = 'Windows 11 21H2 (build {0}): no longer updated, without the Ryzen optimization.'
$EN['Paramètres > Windows Update : passe à la dernière version de Windows 11.'] = 'Settings > Windows Update: move to the latest Windows 11 version.'
$EN['Windows 10 (build {0}) : pas d''optimisation Ryzen récente, plus suivi depuis octobre 2025.'] = 'Windows 10 (build {0}): no recent Ryzen optimization, unsupported since October 2025.'
$EN['Passe à Windows 11 si ton PC est compatible (Paramètres > Windows Update).'] = 'Move to Windows 11 if your PC is compatible (Settings > Windows Update).'
$EN['Jeux sur disque dur'] = 'Games on a hard drive'
$EN['{0} jeu(x) sur HDD'] = '{0} game(s) on HDD'
$EN['Lecteur(s) {0} : disque dur. Chargements plus longs et saccades possibles dans les jeux récents.'] = 'Drive(s) {0}: hard drive. Longer loading and possible stutter in recent games.'
$EN['Déplace les jeux récents vers un SSD (Steam : clic droit sur le jeu > Propriétés > Fichiers installés > Déplacer).'] = 'Move recent games to an SSD (Steam: right-click the game > Properties > Installed Files > Move).'
$EN['Sur SSD'] = 'On SSD'
$EN['{0} jeu(x) Steam / Epic trouvé(s), aucun sur un disque dur.'] = '{0} Steam / Epic game(s) found, none on a hard drive.'
$EN['Panneau de configuration NVIDIA : G-SYNC activé et synchronisation verticale activée ; dans le jeu : V-Sync coupé, limite à {0} images/s.'] = 'NVIDIA Control Panel: G-SYNC on and Vertical sync on; in the game: V-Sync off, cap at {0} fps.'
$EN['Logiciel AMD : FreeSync activé, attente de synchronisation verticale « toujours activée » ; dans le jeu : V-Sync coupé, limite à {0} images/s.'] = 'AMD Software: FreeSync on, Wait for Vertical Refresh "Always on"; in the game: V-Sync off, cap at {0} fps.'
$EN['Active FreeSync / G-Sync dans le menu de l''écran et le logiciel de la carte graphique, puis limite le jeu à {0} images/s.'] = 'Turn on FreeSync / G-Sync in the monitor menu and the graphics card software, then cap the game at {0} fps.'
$EN['Écran à fréquence variable (FreeSync / G-Sync)'] = 'Variable refresh rate monitor (FreeSync / G-Sync)'
$EN['Écran à {0} Hz : limiter les images/s à {1} garde la fréquence variable active (moins de latence, pas de déchirure).'] = '{0} Hz monitor: capping at {1} fps keeps variable refresh active (less latency, no tearing).'
$EN['Vérification du matériel et de Windows...'] = 'Checking hardware and Windows...'
$EN['Le diagnostic n''a pas pu être fait (voir le Journal).'] = 'Diagnostics could not run (see the Log).'
$EN['{0} point(s) à revoir (en orange). Rien n''est modifié : suis le conseil de chaque carte.'] = '{0} item(s) to review (in orange). Nothing is changed: follow each card''s advice.'
$EN['VÉRIFICATIONS (LECTURE SEULE)'] = 'CHECKS (READ-ONLY)'
$EN['Vérifications du matériel et de Windows, avec quoi faire. Lecture seule : rien n''est modifié.'] = 'Hardware and Windows checks, with what to do. Read-only: nothing is changed.'
$EN['SysMain (lancement rapide des applis)'] = 'SysMain (fast app launch)'
$EN['Windows Search (recherche du menu Démarrer)'] = 'Windows Search (Start menu search)'
$EN['Spouleur d''impression (pour imprimer)'] = 'Print Spooler (for printing)'
$EN['Audio Windows (le son)'] = 'Windows Audio (sound)'
$EN['Périphériques audio (le son)'] = 'Audio devices (sound)'
$EN['Thèmes (apparence de Windows)'] = 'Themes (Windows appearance)'
$EN['Horloge de démarrage forcée (useplatformclock)'] = 'Forced boot clock (useplatformclock)'
$EN['Valeur : {0}. Horloge lente réservée au débogage : peut faire perdre des images/s. Réparer = valeur de Windows (après redémarrage).'] = 'Value: {0}. Slow clock meant for debugging: can cost FPS. Repair = Windows value (after restart).'
$EN['Minuterie forcée (useplatformtick)'] = 'Forced timer (useplatformtick)'
$EN['Valeur : {0}. Réglage de débogage sans gain prouvé. Réparer = valeur de Windows (après redémarrage).'] = 'Value: {0}. Debugging setting with no proven gain. Repair = Windows value (after restart).'
$EN['Minuterie dynamique coupée (disabledynamictick)'] = 'Dynamic tick disabled (disabledynamictick)'
$EN['Valeur : {0}. Aucun gain prouvé, plus de consommation. Réparer = valeur de Windows (après redémarrage).'] = 'Value: {0}. No proven gain, more power use. Repair = Windows value (after restart).'
$EN['Synchronisation d''horloge forcée (tscsyncpolicy)'] = 'Forced clock sync (tscsyncpolicy)'
$EN['Aucun fichier d''échange : plantages possibles quand la mémoire est pleine.'] = 'No page file: crashes are possible when memory is full.'
$EN['Limité à {0} Mo : plantages possibles quand la mémoire est pleine.'] = 'Limited to {0} MB: crashes are possible when memory is full.'
$EN['Fichier d''échange absent ou trop petit'] = 'Page file missing or too small'
$EN['Réparer = taille gérée par Windows (après redémarrage).'] = 'Repair = size managed by Windows (after restart).'
$EN['Désactivé, souvent par un autre optimiseur. Réparer = démarrage par défaut de Windows.'] = 'Disabled, often by another optimizer. Repair = Windows default startup.'
$EN['Ne répare que si tu imprimes.'] = 'Only repair it if you print.'
$EN['Service désactivé : {0}'] = 'Service disabled: {0}'
$EN['Compression de la mémoire coupée'] = 'Memory compression off'
$EN['Windows compresse la mémoire peu utilisée au lieu d''écrire sur le disque : la couper ne fait rien gagner. Réparer = la réactiver.'] = 'Windows compresses rarely used memory instead of writing it to disk: turning it off gains nothing. Repair = turn it back on.'
$EN['« Optimiser les lecteurs » désactivé'] = '"Optimize drives" disabled'
$EN['Tâche Windows qui garde les SSD rapides (TRIM) chaque semaine. Réparer = la réactiver.'] = 'Windows task that keeps SSDs fast (TRIM) every week. Repair = turn it back on.'
$EN['Limitation réseau multimédia modifiée'] = 'Multimedia network throttling changed'
$EN['NetworkThrottlingIndex = {0}. Aucun gain prouvé, peut gêner le son et le réseau. Réparer = valeur de Windows (10).'] = 'NetworkThrottlingIndex = {0}. No proven gain, can disturb sound and network. Repair = Windows value (10).'
$EN['Priorité des processus modifiée'] = 'Process priority changed'
$EN['Win32PrioritySeparation = {0}. Valeur « magique » sans gain mesuré. Réparer = valeur de Windows (2).'] = 'Win32PrioritySeparation = {0}. "Magic" value with no measured gain. Repair = Windows value (2).'
$EN['Protections du processeur coupées (Spectre / Meltdown)'] = 'CPU protections off (Spectre / Meltdown)'
$EN['Risque de sécurité, gain nul ou très faible sur un processeur récent. Réparer = protections rendues à Windows (après redémarrage).'] = 'Security risk, no or very small gain on a recent CPU. Repair = protections handed back to Windows (after restart).'
$EN['à l''ouverture de session'] = 'at sign-in'
$EN['au démarrage du PC'] = 'at PC startup'
$EN['à heure fixe'] = 'at a set time'
$EN['quand le PC est inactif'] = 'when the PC is idle'
$EN['à une date ou en boucle'] = 'on a date or repeating'
$EN['sur un événement'] = 'on an event'
$EN['autre déclencheur'] = 'other trigger'
$EN['Recherche des réglages laissés par d''autres optimiseurs...'] = 'Looking for settings left by other optimizers...'
$EN['La recherche n''a pas pu être faite (voir le Journal).'] = 'The scan could not run (see the Log).'
$EN['{0} réglage(s) nuisible(s) trouvé(s) : coche ceux à réparer, puis APPLIQUER.'] = '{0} harmful setting(s) found: tick the ones to repair, then APPLY.'
$EN['RÉGLAGES LAISSÉS PAR D''AUTRES OPTIMISEURS'] = 'SETTINGS LEFT BY OTHER OPTIMIZERS'
$EN['Aucun réglage de démarrage, service, fichier d''échange ou valeur « magique » nuisible trouvé.'] = 'No harmful boot setting, service, page file or "magic" value found.'
$EN['WINDOWS UPDATE, DEFENDER, DISTRIBUTION (LECTURE SEULE, JAMAIS MODIFIÉS)'] = 'WINDOWS UPDATE, DEFENDER, DELIVERY OPTIMIZATION (READ-ONLY, NEVER CHANGED)'
$EN['Démarrage : {0}. LuKZyR n''y touche jamais.'] = 'Startup: {0}. LuKZyR never touches it.'
$EN['Désactivé par un autre outil : plus de mises à jour de sécurité. Réactive-le avec l''outil qui l''a coupé.'] = 'Disabled by another tool: no more security updates. Turn it back on with the tool that disabled it.'
$EN['Optimisation de la distribution (service)'] = 'Delivery Optimization (service)'
$EN['Démarrage : {0}. LuKZyR n''y touche jamais (seul le partage entre PC peut être coupé).'] = 'Startup: {0}. LuKZyR never touches it (only sharing between PCs can be turned off).'
$EN['Désactivé par un autre outil : Windows Update et le Store peuvent échouer. Réactive-le avec l''outil qui l''a coupé.'] = 'Disabled by another tool: Windows Update and the Store may fail. Turn it back on with the tool that disabled it.'
$EN['Microsoft Defender actif. LuKZyR n''y touche jamais.'] = 'Microsoft Defender active. LuKZyR never touches it.'
$EN['{0} actif : Defender se met en veille quand un autre antivirus est installé, c''est normal.'] = '{0} active: Defender goes to sleep when another antivirus is installed, that is normal.'
$EN['Aucun antivirus actif trouvé : ouvre Sécurité Windows et réactive la protection en temps réel.'] = 'No active antivirus found: open Windows Security and turn real-time protection back on.'
$EN['TÂCHES PLANIFIÉES D''AUTRES ÉDITEURS'] = 'SCHEDULED TASKS FROM OTHER PUBLISHERS'
$EN['Décochée = rien ne change. Cochée = désactivée au prochain APPLIQUER (annulable). Les tâches de Microsoft, des navigateurs et des antivirus ne sont jamais proposées.'] = 'Unticked = nothing changes. Ticked = disabled at the next APPLY (undoable). Microsoft, browser and antivirus tasks are never offered.'
$EN['Aucune tâche planifiée active d''un autre éditeur.'] = 'No active scheduled task from another publisher.'
$EN['Réglages laissés par d''autres optimiseurs et tâches planifiées d''autres éditeurs. Coche, puis APPLIQUER.'] = 'Settings left by other optimizers and scheduled tasks from other publishers. Tick, then APPLY.'
$EN['Aucun réglage nuisible d''un autre optimiseur'] = 'No harmful setting from another optimizer'
$EN['Diagnostic du matériel sans alerte'] = 'Hardware diagnostics without warnings'
$EN['Désactiver la tâche'] = 'Disable task'
$EN['Réparation des réglages'] = 'Repairing settings'
$EN['{0} réglage(s) appliqué(s) en {1} min · point de restauration récent réutilisé (créé il y a moins de 10 min).'] = '{0} setting(s) applied in {1} min · recent restore point reused (created less than 10 min ago).'
